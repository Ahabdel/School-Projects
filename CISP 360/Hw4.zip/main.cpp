// main.cpp
// Ahmad Abdelrahman
// 07/1/2024

#include <iostream>
#include <iomanip>
using namespace std;



int MenuChoice;
int numTickets;
int Yen;
int USD;
int Euro;
int Pound;
float Conversion;


const float YEN2USD = 0.0062;
const float EURO2USD = 1.07;
const float Pound2USD = 1.26;
const float USD2YEN = 161.53;
const float USD2EURO = 0.93;
const float USD2Pound = 0.79;

// Speciﬁcation B1 - Three Functions
void welcome();
void menu();
void switchMenu();
void AutoHeading(const string& title);
void MenuOption(int &MenuChoice, int &numTickets);
void CalculatePound2USD();
void CalculateUSD2Pound();
void CalculateEuro2USD();
void CalculateUSD2Euro();
void CalculateYen2USD();
void CalculateUSD2Yen();
void programEnd();



int main() {
  
  welcome();
  menu();
}


void welcome() {
  cout << "Hello, Welcome to Currency Converter Calculator!\n";
}

// Speciﬁcation C1 - Main Menu
// Speciﬁcation B3 - Convert All 
void menu() {
  
  cout << endl << "Select Menu: " << endl;
  cout << "1. USD -> Yen" << endl;
  cout << "2. USD -> Euro" << endl;
  cout << "3. USD -> British Pound" << endl;
  cout << "4. Flip Conversion" << endl;
  cout << "5. Complete all Conversions" << endl;
  cout << endl << "Type Menu Option: ";
  cin >> MenuChoice;
  if (MenuChoice == 1) {
    CalculateUSD2Yen();
    programEnd();

  } else if (MenuChoice == 2) {
    CalculateUSD2Euro();
    programEnd();

  } else if (MenuChoice == 3) {
    CalculateUSD2Pound();
    programEnd();

  } else if (MenuChoice == 4) {
    switchMenu();
  } // Speciﬁcation B3 - Convert All 
 else if (MenuChoice == 5) {
    CalculateUSD2Yen();
    CalculateUSD2Euro();
    CalculateUSD2Pound();
    programEnd();
    
  } else {
    cout << "\033[31mNot Valid Input!\033[0m";
    programEnd();
  }
  
}

// Speciﬁcation C2 - Reverse Menu 
void switchMenu() {
  
  cout << endl << "Select Menu: " << endl;
  cout << "1. Yen -> USD" << endl;
  cout << "2. Euro -> USD" << endl;
  cout << "3. British Pound -> USD" << endl;
  cout << "4. Flip Conversion" << endl;
  cout << "5. Complete all Conversions" << endl;
  cout << endl << "Type Menu Option: ";
  cin >> MenuChoice;
  if (MenuChoice == 1) {
    CalculateYen2USD();
    programEnd();
  } else if (MenuChoice == 2) {
    CalculateEuro2USD();
    programEnd();
  } else if (MenuChoice == 3) {
    CalculatePound2USD();
    programEnd();
  } else if (MenuChoice == 4) {
    menu();
  } // Speciﬁcation B3 - Convert All 
else if (MenuChoice == 5) {
  CalculateYen2USD();
  CalculateEuro2USD();
  CalculatePound2USD();
  programEnd();
    
  
  } // Specification A2 - Valid Menu Selection only
else {
  cout << "\033[31mNot Valid Input!\033[0m";
  programEnd();
  }
  
}



// Speciﬁcation B2 - Conversion Function(s) 
// Specification A1 - Sanity Check
void CalculatePound2USD() {
  cout << endl << "British Pound: £";
  cin >> Pound;
  if (Pound > 100000 || Pound < 0) {
    cout << "\033[31mValue to high!\033[0m";
    exit(0);
  } else {
    Conversion = Pound * Pound2USD;
    cout << endl << "£" << Pound << " British Pound -> £" << Conversion << " USD" ;
  }
}
void CalculateUSD2Pound() {
  
  cout << endl << "USD: $";
  cin >> USD;
  if (USD > 100000 || USD < 0) {
    cout << "\033[31mValue to high!\033[0m";
    exit(0);
  } else {
    Conversion = USD * USD2Pound;
    cout << endl << "$" << USD << " USD -> €" << Conversion << " British Pound" << endl;
  }
}
void CalculateEuro2USD() {
  cout << endl << "Euro: €";
  cin >> Euro;
  if (Euro > 100000 || Euro < 0) {
    cout << "\033[31mValue to high!\033[0m";
    exit(0);
  } else {
    Conversion = Euro * EURO2USD;
    cout << endl << "€" << Euro << " Euro -> €" << Conversion << " USD" ;
  }
}
void CalculateUSD2Euro() {
  cout << endl << "USD: $";
  cin >> USD;
  if (USD > 100000 || USD < 0) {
    cout << "\033[31mValue to high!\033[0m";
    exit(0);
  } else {
    Conversion = USD * USD2EURO;
    cout << endl << "$" << USD << " USD -> €" << Conversion << " Euro" << endl;
  }
}
void CalculateYen2USD() {
  cout << endl << "Yen: ¥";
  cin >> Yen;
  if (Yen > 100000 || Yen < 0) {
    // Specification A3 - Red Error Text
    cout << "\033[31mValue to high!\033[0m";
    exit(0);
  } else {
    Conversion = Yen * YEN2USD;
    cout << endl << "¥" << Yen << " Yen -> $" << Conversion << " USD" ;
  }

}
void CalculateUSD2Yen() {
  cout << "USD: $";
  cin >> USD;
  if (USD > 100000 || USD < 0) {
    cout << "\033[31mValue to high!\033[0m";
    exit(0);
  } else {
    Conversion = USD * USD2YEN;
    cout << endl << "$" << USD << " USD -> ¥" << Conversion << " Yen" << endl;
  }
}




void programEnd() {
  cout << endl << "Program has ended!";
}


// Commented Sample Run:
/*
Hello, Welcome to Currency Converter Calculator!

Select Menu: 
1. USD -> Yen
2. USD -> Euro
3. USD -> British Pound
4. Flip Conversion
5. Complete all Conversions

Type Menu Option: 4

Select Menu: 
1. Yen -> USD
2. Euro -> USD
3. British Pound -> USD
4. Flip Conversion
5. Complete all Conversions

Type Menu Option: 3

British Pound: £1000

£1000 British Pound -> £1260 USD
Program has ended! 
*/

