// main.cpp
// Ahmad Abdelrahman
// 07/14/2024

#include <iostream>
#include <iomanip>
#include <chrono>
#include <random>
#include <fstream>
#include <cmath>
#include <sstream>
#include <limits>
#include <ctime>
 
using namespace std;
using namespace std::chrono;

const float ErrorMargin = 0.05;



void welcome();
int sumIntArray(const int arr[], int size);
float sumFloatArray(const float arr2[], int size);
int minIntArray(const int arr[], int size);
int maxIntArray(const int arr[], int size);
float minFloatArray(const float arr2[], int size);
float maxFloatArray(const float arr2[], int size);
bool searchIntArray(const int arr[], int size, int value);
bool searchFloatArray(const float arr2[], int size, float value, float margin = ErrorMargin);
void reverseIntArray(int arr[], int size);
void reverseFloatArray(float arr2[], int size);
void shiftRightIntArray(int arr[], int size);
void shiftLeftFloatArray(float arr2[], int size);
void displayIntArray(const int arr[], int size);
void displayFloatArray(const float arr2[], int size);
void logFunctionCall(const string& functionName);

// Specification A3 - Random Number in Singleton Pattern

class AhmadRandNumGen {

private:

    static AhmadRandNumGen* unique;
    AhmadRandNumGen() {
            srand(time(0)); 
    }

public:

static AhmadRandNumGen* getInstance() {
        if (!unique) {
            unique = new AhmadRandNumGen();
        }
        return unique;
    }

    int GenNumRandom() {
        return rand() % 101; 
    }

};


AhmadRandNumGen* AhmadRandNumGen::unique = nullptr;

// Specification A2 - Implement a Stack
class EndResultStack {

private:

    int StackArr[100]; 
    int StackTop;

public:

    EndResultStack() : StackTop(-1) {}

    void FunctionPush(int value) {
        logFunctionCall("FunctionPush");
        if (StackTop < 99) {
            StackArr[++StackTop] = value;
        }
    }

    int FunctionPop() {
        logFunctionCall("FunctionPop");
        if (StackTop >= 0) {
            return StackArr[StackTop--];
        }
        return -1; 
    }

    void Display() const {
        logFunctionCall("Display");
        for (int i = 0; i <= StackTop; ++i) {
            cout << StackArr[i] << " ";
        }
        cout << endl;
    }

    bool isEmpty() const {
        return StackTop == -1;
    }

    int getTop() const {
        return StackTop;
    }
};

int main() {
  
  welcome();

    
    // Specification A3 - Random Number in Singleton Pattern

    AhmadRandNumGen* rng = AhmadRandNumGen::getInstance();
    int arr[10];
    for (int i = 0; i < 10; ++i) {
        arr[i] = rng->GenNumRandom();
    }
    float arr2[10] = {1.2, 2.3, 3.4, 4.5, 5.6, 6.7, 7.8, 8.9, 9.1, 10.1};


  // Speciﬁcation C1 – Display Array 
    cout << "\nHere are the Original Arrays"
         << endl << "----------------------------\n"
         << "\nOriginal integer array: ";
    displayIntArray(arr, 10);

    cout << "Original float array: ";
    displayFloatArray(arr2, 10);
   
    // Speciﬁcation B2 – A Ray Reversal 

    reverseIntArray(arr, 10);
    reverseFloatArray(arr2, 10);

    cout << "\nNow let's reverse these arrays.........\n"
         << "\nReversed Arrays:\n"
         << "-----------------------\n"
         << "Reversed integer array: ";
    displayIntArray(arr, 10);

    cout << "Reversed float array: ";
    displayFloatArray(arr2, 10);

    // Speciﬁcation B3 - Element Shift 
    shiftRightIntArray(arr, 10);
    shiftLeftFloatArray(arr2, 10);

    cout << "\nNow let's Shift these arrays, once left amd once right.........\n"
         << "\nShifted Arrays:\n"
         << "-----------------------\n"
         << "Shifted right integer array: ";
    displayIntArray(arr, 10);

    cout << "Shifted left float array: ";
    displayFloatArray(arr2, 10);
    
  // Speciﬁcation C2 – Sum 

    int intSum = sumIntArray(arr, 10);
    float floatSum = sumFloatArray(arr2, 10);

    cout << "\nNow let's Sum these arrays.........\n"
         << "\nSummed Up Arrays:\n"
         << "-----------------------\n"
         << "Sum of integer array: " << intSum << endl
         << "Sum of float array: " << fixed << setprecision(1) << floatSum << endl;



    int intMin = minIntArray(arr, 10);
    int intMax = maxIntArray(arr, 10);
    float floatMin = minFloatArray(arr2, 10);
    float floatMax = maxFloatArray(arr2, 10);

    cout << "\nNow let's Find the Max and Min of these arrays.........\n"
         << "\nMax and Min of each array:\n"
         << "-----------------------\n"
         << "integer array Min: " << intMin << endl
         << "integer array Max: " << intMax << endl
         << "float array Min: " << fixed << setprecision(1) << floatMin << endl
         << "float array Max: " << fixed << setprecision(1) << floatMax << endl;

    // Speciﬁcation B1 – Value Hunt 
    int intValue;
    float floatValue;


    cout << "\nNow it's your turn to discover what's in these arrays.........\n"
         << "\nEnter a number that you think is in the integer array:\n"
         << "-----------------------\n";
    cout << "Search for this number: ";
    cin >> intValue;
    if (searchIntArray(arr, 10, intValue)) {
        cout << endl << "Congratulations! ";
        cout << "Integer " << intValue << " was found in the array! Great Job!" << endl;
    } else {
        cout << endl << "Nice try but ";
        cout << "Integer " << intValue << " was not found in the array. Good luck next time!" << endl;
    }

    cout << "---------------------------\n"
         << "\nEnter a float to search: ";
    cin >> floatValue;
    if (searchFloatArray(arr2, 10, floatValue)) {
        cout << endl << "Congratulations! "
             << "Float " << floatValue << " was found in the array! Great Job!" << endl;
    } else {
        cout << endl << "Nice try but "
             << "Float " << floatValue << " was not found in the array. Good luck next time!" << endl;
    }

    EndResultStack stack;
    int numValues = 15 + rand() % 11; 
    for (int i = 0; i < numValues; ++i) {
        int randomValue = rng->GenNumRandom(); 
        stack.FunctionPush(randomValue);
    }


    // Specification A2 - Implement a Stack

    cout << "\nGreat Job Program is ending now........Here is the stack content:\n"
         << "-----------------------------\n"
         << "\nStack contents: \n";
    stack.Display();
 
}



void logFunctionCall(const string& functionName) {
    ofstream logFile("log.txt", ios::app);
    if (logFile.is_open()) {
        auto now = system_clock::to_time_t(system_clock::now());
        logFile << put_time(localtime(&now), "%Y-%m-%d %H:%M:%S") << " - " << functionName;
        logFile << endl;
        logFile.close();
    }
}


// Specification A1 - Function Activity to Disk

void welcome() {
    logFunctionCall("welcome");
    cout << "Hello, Welcome to Ahmad's Array Demonstrator!\n"
         << endl << "Let's Start with display the arrays:\n";
}

int sumIntArray(const int arr[], int size) {
    logFunctionCall("sumIntArray");
    int sum = 0;
    for (int i = 0; i < size; ++i) {
        sum += arr[i];
    }
    logFunctionCall("sumIntArray");
    return sum;
}

float sumFloatArray(const float arr2[], int size) {
    logFunctionCall("sumFloatArray");
    float sum = 0;
    for (int i = 0; i < size; ++i) {
        sum += arr2[i];
    }
    logFunctionCall("sumFloatArray");
    return sum;
}

int minIntArray(const int arr[], int size) {
    logFunctionCall("minIntArray");
    int min = arr[0];
    for (int i = 1; i < size; ++i) {
        if (arr[i] < min) {
            min = arr[i];
        }
    }
    logFunctionCall("minIntArray");
    return min;
}

int maxIntArray(const int arr[], int size) {
    logFunctionCall("maxIntArray");
    int max = arr[0];
    for (int i = 1; i < size; ++i) {
        if (arr[i] > max) {
            max = arr[i];
        }
    }
    logFunctionCall("maxIntArray");
    return max;
}

float minFloatArray(const float arr2[], int size) {
    logFunctionCall("minFloatArray");
    float min = arr2[0];
    for (int i = 1; i < size; ++i) {
        if (arr2[i] < min) {
            min = arr2[i];
        }
    }
    logFunctionCall("minFloatArray");
    return min;
}

float maxFloatArray(const float arr2[], int size) {
    logFunctionCall("maxFloatArray");
    float max = arr2[0];
    for (int i = 1; i < size; ++i) {
        if (arr2[i] > max) {
            max = arr2[i];
        }
    }
    logFunctionCall("maxFloatArray");
    return max;
}

bool searchIntArray(const int arr[], int size, int value) {
    logFunctionCall("searchIntArray");
    for (int i = 0; i < size; ++i) {
        if (arr[i] == value) {
            logFunctionCall("searchIntArray");
            return true;
        }
    }
    logFunctionCall("searchIntArray");
    return false;
}

bool searchFloatArray(const float arr2[], int size, float value, float margin) {
    logFunctionCall("searchFloatArray");
    for (int i = 0; i < size; ++i) {
        if ((arr2[i] - value) <= margin) {
            logFunctionCall("searchFloatArray");
            return true;
        }
    }
    logFunctionCall("searchFloatArray");
    return false;
}

void reverseIntArray(int arr[], int size) {
    logFunctionCall("reverseIntArray");
    for (int i = 0; i < size / 2; ++i) {
        int temp = arr[i];
        arr[i] = arr[size - 1 - i];
        arr[size - 1 - i] = temp;
    }
    logFunctionCall("reverseIntArray");
}

void reverseFloatArray(float arr2[], int size) {
    logFunctionCall("reverseFloatArray");
    for (int i = 0; i < size / 2; ++i) {
        float temp = arr2[i];
        arr2[i] = arr2[size - 1 - i];
        arr2[size - 1 - i] = temp;
    }
    logFunctionCall("reverseFloatArray");
}

void shiftRightIntArray(int arr[], int size) {
    logFunctionCall("shiftRightIntArray");
    int last = arr[size - 1];
    for (int i = size - 1; i > 0; --i) {
        arr[i] = arr[i - 1];
    }
    arr[0] = last;
    logFunctionCall("shiftRightIntArray");
}

void shiftLeftFloatArray(float arr2[], int size) {
    logFunctionCall("shiftLeftFloatArray");
    float first = arr2[0];
    for (int i = 0; i < size - 1; ++i) {
        arr2[i] = arr2[i + 1];
    }
    arr2[size - 1] = first;
    logFunctionCall("shiftLeftFloatArray");
}

void displayIntArray(const int arr[], int size) {
    logFunctionCall("displayIntArray");
    for (int i = 0; i < size; ++i) {
        cout << arr[i] << " ";
    }
    cout << endl;
}

void displayFloatArray(const float arr2[], int size) {
    logFunctionCall("displayFloatArray");
    for (int i = 0; i < size; ++i) {
        cout << fixed << setprecision(1) << arr2[i] << " ";
    }
    cout << endl;
}




// Commented Sample Run:
/*

Hello, Welcome to Ahmad's Array Demonstrator!

Let's Start with display the arrays:

Here are the Original Arrays
----------------------------

Original integer array: 58 30 59 9 38 63 84 52 26 81 
Original float array: 1.2 2.3 3.4 4.5 5.6 6.7 7.8 8.9 9.1 10.1 

Now let's reverse these arrays.........

Reversed Arrays:
-----------------------
Reversed integer array: 81 26 52 84 63 38 9 59 30 58 
Reversed float array: 10.1 9.1 8.9 7.8 6.7 5.6 4.5 3.4 2.3 1.2 

Now let's Shift these arrays, once left amd once right.........

Shifted Arrays:
-----------------------
Shifted right integer array: 58 81 26 52 84 63 38 9 59 30 
Shifted left float array: 9.1 8.9 7.8 6.7 5.6 4.5 3.4 2.3 1.2 10.1 

Now let's Sum these arrays.........

Summed Up Arrays:
-----------------------
Sum of integer array: 500
Sum of float array: 59.6

Now let's Find the Max and Min of these arrays.........

Max and Min of each array:
-----------------------
Min of integer array: 9
Max of integer array: 84
Min of float array: 1.2
Max of float array: 10.1

Now it's your turn to discover what's in these arrays.........

Enter a number that you think is in the integer array:
-----------------------
Search for this number: 10

Nice try but Integer 10 was not found in the array. Good luck next time!
---------------------------

Enter a float to search: 20

Congratulations! Float 20.0 was found in the array! Great Job!

Great Job Program is ending now........Here is the stack content:
-----------------------------

Stack contents: 
16 54 89 81 31 46 60 6 9 92 64 38 38 100 48 57 90 11 59 68 69 89 27 44 
 
  */



