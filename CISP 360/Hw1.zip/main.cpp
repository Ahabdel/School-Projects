// Specification C2: Source File Header
// main.cpp
// Ahmad Abdelrahman
// 04/16/2024

#include <iostream>
using namespace std;

// Specification B1: Initialize Variables
int num = 0;
float floaty = 2.23;
double doubling = 2.2;
bool lool = true;
char letter = 'A';
string text = "Ahmad is Cool";


int main() {
  // Specification C1: Program Greeting
  cout << "Welcome to Ahmad's Amazing CISP 360 Program!" << endl;
  
  // Specification B2: Output Variables
  cout << num << endl << floaty << endl << doubling << endl << lool << endl << letter << endl << text;
           
}

// Specification A: Commented Sample Run
/*
Output:
0
2.23
2.2
1
A
Ahmad is Cool 
*/