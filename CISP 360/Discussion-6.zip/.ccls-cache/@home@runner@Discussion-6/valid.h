#include <iostream>
using namespace std;

// validates an integer and returns it
// Pre: none
// Post: a valid integer is returned
int getInteger(string prompt = "Enter Integer: "){
    int num = 0;
    cout << prompt;
    while (!(cin >> num) || cin.peek() != '\n'){
        cin.clear();
        while (cin.get() != '\n');
        cout << "Invalid Integer.\n"
             << prompt;
    }
    cin.get();

    return num;
}
