/******************************************************************************
# Author:           Ahmad Abdelrahman, Branden Goodwin
# Assignment:       Discussion 6
# Date:             04/24/2024
# Description:      The program educates the user about the three different
#                   uses of the the * operator in C++: multiplication,
#                   dereferencing a pointer, and pointer declaration. It
#                   features  a menu where users can select an option to learn
#                   about each use and see an example of how the * operator
#                   works in the chosen context. The user can then test their
#                   knowledge and the program will tell them if they're
#                   correct.
#                   Sources: https://learn.zybooks.com/
#                            replit.com
#                            C ++ Style Guide
#                   Work Divide:
#                   Ahmad: showMultiplication, planning document, 
#                          showDereferencing, showPointerDeclaration
#
#                   Branden: main(), print functions, valid.h,
#                                getMenuChoice(), test functions
# Struggled most:   Branden: Developing an algorithm to randomize multiple
#                            choice questions.
#                   Ahmad: Style and correct syntax
#******************************************************************************/

#include <iostream>
#include <iomanip>
#include "valid.h"
using namespace std;

// function prototypes
void printWelcome();
void printGoodbye();
void printMainMenu();
void printDeclareMenu();
void printDerefMenu();
void printMultiplicationMenu();
int getMenuChoice(int choices);
void showMultiplication();
void showDereferencing();
void showPointerDeclaration();
void testMultiplication();
void testDereferencing();
void testPointerDeclaration();

int main() {
    int menuChoice = 0;

    srand(time(0));
  
    printWelcome();
    
    // Main Menu Loop
    while (!(menuChoice == 4)){
        printMainMenu();
        menuChoice = getMenuChoice(4);
      
        // Pointer Declaration Sub-Menu Loop
        if (menuChoice == 1){
            menuChoice = 0;
            while (!(menuChoice == 3)){
                printDeclareMenu(); 
                menuChoice = getMenuChoice(3);
                if (menuChoice == 1){
                    showPointerDeclaration();
                }
                else if (menuChoice == 2){
                    testPointerDeclaration();
                }
            }
        }
        // Dereference Sub-Menu Loop
        else if (menuChoice == 2){
            menuChoice = 0;
            while (!(menuChoice == 3)){
                printDerefMenu();
                menuChoice = getMenuChoice(3);
                if (menuChoice == 1){
                    showDereferencing();
                }
                else if (menuChoice == 2){
                    testDereferencing();
                }
            }
        }
        // Multiplication Sub-Menu Loop
        else if (menuChoice == 3){
            menuChoice = 0;
            while (!(menuChoice == 3)){
                printMultiplicationMenu();
                menuChoice = getMenuChoice(3);
                if (menuChoice == 1){
                    showMultiplication();
                }
                else if (menuChoice == 2){
                    testMultiplication();
                }
            }
        }
    }
    
    printGoodbye();
    
    return 0;
}


// prints the main menu
// Pre: none
// Post: main menu is printed
void printMainMenu(){
    cout << "\n1. Pointer Declaration" << endl
         << "2. Dereferencing" << endl
         << "3. Multiplication" << endl
         << "4. Exit Program" << endl;
}


// prints pointer declaration submenu
// Pre: none
// Post: declaration menu is printed
void printDeclareMenu(){
    cout << "\n1. How to declare a pointer" << endl
         << "2. Test Pointer Declaration Knowledge" << endl
         << "3. Return to Main" << endl;
}


// prints dereference submenu
// Pre: none
// Post: dereference menu is printed
void printDerefMenu(){
    cout << "\n1. Show Dereferencing" << endl
         << "2. Test Dereferencing Knowledge" << endl
         << "3. Return to Main" << endl;
}


// prints multiplication menu
// Pre: none
// Post: multiplication menu is printed
void printMultiplicationMenu(){
    cout << "\n1. Multiplication Example" << endl
         << "2. Test Multiplication Knowledge" << endl
         << "3. Return to Main" << endl;
}


// prompts for menu choice, validates the choice, and returns it
// Pre: the number of choices is passed as an integer argument and is >= 1
// Post: the menu choice is returned
int getMenuChoice(int choices){
    int num = 0;
    string prompt = "Choice: ";
    num = getInteger(prompt);
    while (num < 1 || num > choices){
        cout << "Invalid choice. Please enter 1-" << choices << ".\n";
        num = getInteger(prompt);
    }
    return num;
}


// prints a welcome message
// Pre: none
// Post: welcome message is printed
void printWelcome(){
    cout << "This program will help you understand the * operator in C++.\n"
         << "Navigate through menus by entering the corresponding numbers.\n"
         << "Each section will teach you about different use cases and\n"
         << "give you an opportunity to test your knowledge. You are\n"
         << "encouraged to test yourself multiple times. Good luck!\n";
}


// prints a goodbye message
// Pre: none
// Post: goodbye message is printed
void printGoodbye(){
    cout << "\nThank you and goodbye. Happy coding!\n";
}


// prompts user to input two integer and calculates the product
// It also demonstrates the syntax and use of the * operator
// Pre: none
// Post: Outputs the multiplication example to the user, showing the syntax
// and the result of multiplying the two integers.
void showMultiplication() {
    cout << "\nThis part of the program demonstrates the use of the '*' "
            "operator for multiplication.\n";
    int a = getInteger("Enter the 1st integer to multiply: ");
    int b = getInteger("Enter the 2nd integer to multiply: ");
    cout << "\nThe syntax for multiplication in C++ is: a * b\n";
    cout << "Example: " << a << " * " << b << " = " << a * b << endl;
    cout << "In this example, " << a << " and " << b << " are multiplied "
            "to give " << a * b << ", "
         << "demonstrating how the '*' operator is used to calculate the "
            "product of two numbers.\n";
}


// prompts the user to enter an integer, stores it in a variable via a
// pointer, and then dereferences the pointer to access 
// and display the value.
// Pre: none
// Post: Outputs an example of dereferencing by showing the syntax and
// displaying the value entered by the user via dereferencing the pointer.
void showDereferencing() {
    cout << "\nDereferencing a pointer means accessing the value at the "
            "memory address held by the pointer.\n"
         << "We will now demonstrate this with an example.\n";
    int value = 0;
    cout << "Currently, we have declared an integer 'value' initialized "
            "to 0.\n";
    int *pointer = &value;
    cout << "A pointer 'pointer' is now pointing to 'value'. The address of "
            "'value' is: " << &value << endl;
  
    cout << "\nEnter a new integer to store in 'value' through the "
            "pointer.\n";
    *pointer = getInteger("New Integer: ");
    cout << "\nThe syntax for dereferencing is: *pointer\n"
         << "You entered: " << *pointer << ", which is now stored at "
            "address " 
         << pointer << endl;
}


// displays the syntax and an example of how to declare a pointer in C++.
// Pre: none
// Post: Outputs the syntax for declaring a pointer and provides a clear 
// example of declaring an integer pointer.
void showPointerDeclaration() {
    cout << "\nDeclaring a pointer involves specifying the type of data "
      "it points to followed by an asterisk (*) and the pointer "
      "name.\n"
    << "Example syntax: type *pointerName;\n"
    << "\nLet's declare a pointer that points to an integer.\n"
    << "Example: int *myPointer;\n"
    << "Here, 'myPointer' is a pointer that can hold the address "
      "of an integer variable.\n"
    << "To demonstrate, we will declare an integer 'num' and make "
      "'myPointer' point to it.\n";
  
    int num = 10;
    int *myPointer = &num;
    cout << "The integer 'num' has a value of 10 and is located at "
      "address: " << &num << "\n"
    << "'myPointer' now holds this address. Dereferencing "
      "'myPointer' gives us the value: " << *myPointer << endl;
}


// prompts the user to guess what a snippet of code prints
// then tells them if they got it right
// Pre: none
// Post: correct or incorrect message is printed
void testMultiplication(){
    int guess = 0;
    int num1 = rand() % 10 + 1;
    int num2 = rand() % 10 + 1;
    int result = num1 * num2;
    cout << "\nWhat number does the following code display?\n"
         << "\nint num1 = " << num1 << ";"
         << "\nint num2 = " << num2 << ";"
         << "\nint result = num1 * num2;"
         << "\ncout << result;\n\n";

    guess = getInteger("Guess: ");
    if (guess == result){
        cout << "\nCorrect! Good job!\n";
    }
    else {
        cout << "\nIncorrect. The answer was " << result << ".\n"
             << "Remember, when placed between two numbers (including\n"
             << "variable numbers), the * symbol acts like multiplication.\n";
    }
}


// prompts the user to guess what a snippet of code prints
// then tells them if theyg ot it right
// Pre: none
// Post: correct or incorrect message is printed
void testDereferencing(){
    int num1 = rand() % 10 + 1;
    int num2 = rand() % 10 + 11;
    int guess = 0;
  
    cout << "\nWhat will the following code display?\n"
         << "\nint* pointerVar;\n"
         << "int num = " << num1 << ";\n"
         << "pointerVar = &num;\n"
         << "num = " << num2 << ";\n"
         << "cout << *pointerVar;\n\n";
  
    guess = getInteger("Guess: ");
    if (guess == num2){
        cout << "\nCorrect! Good job!\n";
    }
    else {
        cout << "\nIncorrect. The answer was " << num2 << ".\n"
             << "Remember, pointer variables store addresses, not values.\n"
             << "When the value stored at an address changes, the address\n"
             << "remains the same. The value is retrieved with "
             << "the * operator.\n";
    }
}


// displays a question and a scrambled set of multiple choice answers
// then aks the user to guess and prints a correct/incorrect message
// Pre: none
// Post: correct/incorrect message is displayed
void testPointerDeclaration(){
    int size = 9;
    string answers[9] = {"int* pointerVar = &x;", "int pointerVar = &x;",
                         "int* pointerVar = *x;", "int pointerVar = *x;",
                         "int* pointerVar = x;", "int pointerVar = x;",
                         "int& pointerVar = &x;", "int& pointerVar = *x;",
                         "int& pointerVar = x;"};
    string solution = "int* pointerVar = &x;";
    int index = 0;
    string temp = "";
    int i = 0;
    int j = 0;
    int guess = 0;

    // loop that scrambles the answer array
    // iterate backwards
    for (i = size -1; i >= 0; --i){
        // choose an index at random
        index = 0;
        if (i > 0){
            index = rand() % (i + 1);
        }
        // right shift the random index
        if (index != i){
            for (j = index; j < i; ++j){
                temp = answers[j];
                answers[j] = answers[j+1];
                answers[j+1] = temp;
            }
        }
    }

    cout << "\nWhat is the correct way to initialize a pointer variable named"
         << "\npointerVar and store the address of following variable in it?\n"
         << "\nint x = 0;\n\n";
  
    // print scrambled array
    for (i = 0; i < size; ++i){
        cout << i + 1 << ". " << answers[i] << endl;
    }

    guess = getInteger("Guess: ");
    while (guess < 1 || guess > size){
        cout << "Please enter 1-" << size << ".\n";
        guess = getInteger("Guess: ") -1;
    }

    if (answers[guess - 1] == solution){
        cout << "\nCorrect! Good job!\n";
    }
    else {
        cout << "\nIncorrect. Remember, the * operator comes between the\n"
             << "data type and the pointer variable name when declaring a\n"
             << "pointer. The & operator when used at the start of a\n"
             << "variable indicates that you're using the variable's\n"
             << "address instead of its value.\n";
    }
}
