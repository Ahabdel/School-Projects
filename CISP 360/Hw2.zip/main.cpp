// main.cpp
// Ahmad Abdelrahman
// 06/23/2024

#include <iostream>
using namespace std;


// Speciﬁcation C1 - Variable Declaration
// Speciﬁcation C2 - Variable Initialization 
int RSC = 7;
float PoSWP = 0.4;
float AvgNumPSS = 0.6;
float PoTDevLife = 0.13;
float Intelife = 0.7;
float ablecomm = 0.9;
int CivLifetime = 1054;
float doubleResults;
float halfResults;

float getCivCalc();
// Speciﬁcation B1 - Calculation 
// Speciﬁcation C3 - Constant Variables 
const float etCiv = RSC * PoSWP * AvgNumPSS * PoTDevLife * Intelife * ablecomm * CivLifetime;

int main() {
  
  cout << "Hello Welcome to Drake Equation Solver!\n";
  
  // Speciﬁcation B2 - Drake Equation Heading 
  cout << endl << "CHANCE OF INTELLIGENT LIFE" << endl << "==========================" << endl;
  cout << etCiv << endl;
  
  // Speciﬁcation B3 - Double and Half Output and Headings 
  doubleResults = etCiv * 2;
  halfResults = etCiv / 2;
  cout << endl << "SENSITIVITY ANALYSIS" << endl << "===================" << endl;
  cout << doubleResults << endl << halfResults << endl;
  
  // Specification A1 - Variable Table
  cout << endl;
  cout << "|---------- Variable Table -----------|" << endl;
  cout << "|-----------------|-------------------|" << endl;
  cout << "|      RSC        |        7          |" << endl;
  cout << "|-----------------|-------------------|" << endl;
  cout << "|     PoSWP       |       0.4         |" << endl;
  cout << "|-----------------|-------------------|" << endl;
  cout << "|   AvgNumPSS     |       0.6         |" << endl;
  cout << "|-----------------|-------------------|" << endl;
  cout << "|   PoTDevLife    |       0.13        |" << endl;
  cout << "|-----------------|-------------------|" << endl;
  cout << "|    Intelife     |       0.7         |" << endl;
  cout << "|-----------------|-------------------|" << endl;
  cout << "|    ablecomm     |       0.9         |" << endl;
  cout << "|-----------------|-------------------|" << endl;
  cout << "|   CivLifetime   |       1054        |" << endl;
  cout << "|-----------------|-------------------|" << endl;

  // Specification A2 - Output Table
  cout << endl;
  cout << "|----------  Output Table  -----------|" << endl;

  cout << "|-----------------|-------------------|" << endl;
  cout << "|                 |   7 * 0.4 * 0.6   |" << endl;
  cout << "| Drake EQ Value  |   * 0.13 * 0.7    |" << endl;
  cout << "|                 |    * 9 * 1054     |" << endl;
  cout << "|-----------------|-------------------|" << endl;
  cout << "|     etCiv       |      145.022      |" << endl;
  cout << "|-----------------|-------------------|" << endl;

  // Specification A3 - Sensitivity Analysis Table
  cout << endl;
  cout << "|---  Sensitivity Analysis Table  ----|" << endl;

  cout << "|-----------------|-------------------|" << endl;
  cout << "|     Double      |      290.044      |" << endl;
  cout << "|-----------------|-------------------|" << endl;
  cout << "|      Half       |       72.511      |" << endl;
  cout << "|-----------------|-------------------|" << endl;
  
}
















// Commented Sample Run:
/*

Hello Welcome to Drake Equation Solver!

CHANCE OF INTELLIGENT LIFE
==========================
145.022

SENSITIVITY ANALYSIS
===================
290.044
72.511

|---------- Variable Table -----------|
|-----------------|-------------------|
|      RSC        |        7          |
|-----------------|-------------------|
|     PoSWP       |       0.4         |
|-----------------|-------------------|
|   AvgNumPSS     |       0.6         |
|-----------------|-------------------|
|   PoTDevLife    |       0.13        |
|-----------------|-------------------|
|    Intelife     |       0.7         |
|-----------------|-------------------|
|    ablecomm     |       0.9         |
|-----------------|-------------------|
|   CivLifetime   |       1054        |
|-----------------|-------------------|

|----------  Output Table  -----------|
|-----------------|-------------------|
|                 |   7 * 0.4 * 0.6   |
| Drake EQ Value  |   * 0.13 * 0.7    |
|                 |    * 9 * 1054     |
|-----------------|-------------------|
|     etCiv       |      145.022      |
|-----------------|-------------------|

|---  Sensitivity Analysis Table  ----|
|-----------------|-------------------|
|     Double      |      290.044      |
|-----------------|-------------------|
|      Half       |       72.511      |
|-----------------|-------------------|

*/
