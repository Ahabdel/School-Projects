#include <iomanip>
#include <iostream>
using namespace std;

const float TICKET_PRICE = 13.50;

// Function to get input from the user
void getInput(string &movie, int &numTickets) {
  cout << "Enter movie name: ";
  getline(cin, movie);
  cout << "Enter number of tickets: ";
  cin >> numTickets;
  cin.ignore(); // Ignore the newline character
}

// Function to calculate the total price
float calculateTotalPrice(int numTickets) { return numTickets * TICKET_PRICE; }

// Function to display the output
void displayOutput(const string &movie, int numTickets, float totalPrice) {
  cout << "\nHere is your order:" << endl;
  cout << fixed << setprecision(2);
  cout << "Movie: " << movie << endl;
  cout << numTickets << " tickets @ $" << TICKET_PRICE << " each." << endl;
  cout << "\nTotal due: $" << totalPrice << endl;
  cout << "\nEnjoy your movie!" << endl;
}

int main() {
  string movie = "";
  int numTickets = 0;
  float totalPrice = 0;

  cout << "Welcome to Living Room Theaters!\n";

  // Get input from the user
  getInput(movie, numTickets);

  // Calculate the total price
  totalPrice = calculateTotalPrice(numTickets);

  // Display the output
  displayOutput(movie, numTickets, totalPrice);

  return 0;
}
