// main.cpp
// Ahmad Abdelrahman
// 06/23/2024

#include <iostream>
#include <iomanip>
using namespace std;



int Newyork = 85;
int Denver = 88;
int Phoenix = 106;
int Sacramento = 92;
float growthRate = 0.13;
float worldsOceanCen = 1.8;
float OceanGrowth = 3.1;
float fahrenheit;
float millimeters;

// Speciﬁcation C1 - const Conversions
// Speciﬁcation B1 - Mixed length output 
// Speciﬁcation B2 - Mixed temperature output
const float F2C = 5.0 / 9.0;
const float MM2IN = 25.4;

// Specification A3 - One Function
void welcome();

// Speciﬁcation B3 - Auto Heading Function 
void AutoHeading(const string& title);


int main() {
  
  welcome();

  // Speciﬁcation C2 - 5 year ocean rise 
  cout << endl << "5 Ocean Rises Per Year in MILLMIMETERS" << endl;
  float year1 = worldsOceanCen + OceanGrowth;
  float year2 = worldsOceanCen + OceanGrowth * 2;
  float year3 = worldsOceanCen + OceanGrowth * 3;
  float year4 = worldsOceanCen + OceanGrowth * 4;
  float year5 = worldsOceanCen + OceanGrowth * 5;
  cout << fixed << setprecision(3);
  cout << endl << "First Year: " << year1 << endl;
  cout << "Second Year: " << year2 << endl;
  cout << "Third Year: " << year3 << endl;
  cout << "Four Year: " << year4 << endl;
  cout << "Fifth Year: " << year5 << endl;

  // Speciﬁcation B1 - Mixed length output 
  cout << endl << "5 Ocean Rises Per Year in INCHES" << endl;
  millimeters = year1;
  year1 = millimeters / MM2IN;
  cout << endl << "First Year: " << year1 << endl;
  millimeters = year2;
  year2 = millimeters / MM2IN;
  cout << "Second Year: " << year2 << endl;
  millimeters = year3;
  year3 = millimeters / MM2IN;
  cout << "Third Year: " << year3 << endl;
  millimeters = year4;
  year4 = millimeters / MM2IN;
  cout << "Four Year: " << year4 << endl;
  millimeters = year5;
  year5 = millimeters / MM2IN;
  cout << "Fifth Year: " << year5 << endl;
  
  // Speciﬁcation C3 - 5 year temp 

  cout << endl << "Mean Temperature Per Year in FAHRENHEIT" << endl;
  float MeanTemp1 = (Newyork + Denver + Phoenix + Sacramento) / 4 + growthRate;
  float MeanTemp2 = (Newyork + Denver + Phoenix + Sacramento) / 4 + growthRate * 2;
  float MeanTemp3 = (Newyork + Denver + Phoenix + Sacramento) / 4 + growthRate * 3;
  float MeanTemp4 = (Newyork + Denver + Phoenix + Sacramento) / 4 + growthRate * 4;
  float MeanTemp5 = (Newyork + Denver + Phoenix + Sacramento) / 4 + growthRate * 5;

  cout << endl << "Mean Temperature Year 1: " << MeanTemp1 << "◦F" << endl;
  cout << "Mean Temperature Year 2: " << MeanTemp2 << "◦F" << endl;
  cout << "Mean Temperature Year 3: " << MeanTemp3 << "◦F" << endl;
  cout << "Mean Temperature Year 4: " << MeanTemp4 << "◦F" << endl;
  cout << "Mean Temperature Year 5: " << MeanTemp5 << "◦F" << endl;

  // Speciﬁcation B2 - Mixed temperature output
  cout << endl << "Mean Temperature Per Year in CELSIUS" << endl;
  fahrenheit = MeanTemp1;
  MeanTemp1 = (fahrenheit - 32) * F2C;
  cout << endl << "Mean Temperature Year 1: " << MeanTemp1 << "◦C" << endl;
  fahrenheit = MeanTemp2;
  MeanTemp2 = (fahrenheit - 32) * F2C;
  cout << "Mean Temperature Year 2: " << MeanTemp2 << "◦C" << endl;
  fahrenheit = MeanTemp3;
  MeanTemp3 = (fahrenheit - 32) * F2C;
  cout << "Mean Temperature Year 3: " << MeanTemp3 << "◦C" << endl;
  fahrenheit = MeanTemp4;
  MeanTemp4 = (fahrenheit - 32) * F2C;
  cout << "Mean Temperature Year 4: " << MeanTemp4 << "◦C" << endl;
  fahrenheit = MeanTemp5;
  MeanTemp5 = (fahrenheit - 32) * F2C;
  cout << "Mean Temperature Year 5: " << MeanTemp5 << "◦C" << endl;
  
  // Specification A1 - Ocean Rise Table
  cout << endl;
  cout << "|------------------ Ocean Rise Table -------------------|" << endl;
  cout << "|-----------------|-------------------|-----------------|" << endl;
  cout << "|      Year       |    Millimeter     |      Inches     |" << endl;
  cout << "|-----------------|-------------------|-----------------|" << endl;
  cout << "|     Year 1      |       4.9         |      0.193      |" << endl;
  cout << "|-----------------|-------------------|-----------------|" << endl;
  cout << "|     Year 2      |       8.0         |      0.315      |" << endl;
  cout << "|-----------------|-------------------|-----------------|" << endl;
  cout << "|     Year 3      |       11.1        |      0.437      |" << endl;
  cout << "|-----------------|-------------------|-----------------|" << endl;
  cout << "|     Year 4      |       14.2        |      0.559      |" << endl;
  cout << "|-----------------|-------------------|-----------------|" << endl;
  cout << "|     Year 5      |       17.3        |      0.681      |" << endl;
  cout << "|-----------------|-------------------|-----------------|" << endl;


  // Specification A2 - July Temp Table
  cout << endl;
  cout << "|------------------- July Temp Table -------------------|" << endl;
  cout << "|-----------------|-------------------|-----------------|" << endl;
  cout << "|      Year       |   Mean Temp(◦F)   |  Mean Temp(◦C)  |" << endl;
  cout << "|-----------------|-------------------|-----------------|" << endl;
  cout << "|     Year 1      |      92.130       |      33.406     |" << endl;
  cout << "|-----------------|-------------------|-----------------|" << endl;
  cout << "|     Year 2      |       92.26       |      33.478     |" << endl;
  cout << "|-----------------|-------------------|-----------------|" << endl;
  cout << "|     Year 3      |      92.390       |      33.55      |" << endl;
  cout << "|-----------------|-------------------|-----------------|" << endl;
  cout << "|     Year 4      |       92.52       |      33.622     |" << endl;
  cout << "|-----------------|-------------------|-----------------|" << endl;
  cout << "|     Year 5      |      92.650       |      33.694     |" << endl;
  cout << "|-----------------|-------------------|-----------------|" << endl;



}


void welcome() {
  cout << "Hello, Welcome to Earth's Climate Change Calculator!\n";
}













// Commented Sample Run:
/*

Hello, Welcome to Earth's Climate Change Calculator!

5 Ocean Rises Per Year in MILLMIMETERS

First Year: 4.900
Second Year: 8.000
Third Year: 11.100
Four Year: 14.200
Fifth Year: 17.300

5 Ocean Rises Per Year in INCHES

First Year: 0.193
Second Year: 0.315
Third Year: 0.437
Four Year: 0.559
Fifth Year: 0.681

Mean Temperature Per Year in FAHRENHEIT

Mean Temperature Year 1: 92.130◦F
Mean Temperature Year 2: 92.260◦F
Mean Temperature Year 3: 92.390◦F
Mean Temperature Year 4: 92.520◦F
Mean Temperature Year 5: 92.650◦F

Mean Temperature Per Year in CELSIUS

Mean Temperature Year 1: 33.406◦C
Mean Temperature Year 2: 33.478◦C
Mean Temperature Year 3: 33.550◦C
Mean Temperature Year 4: 33.622◦C
Mean Temperature Year 5: 33.694◦C

|------------------ Ocean Rise Table -------------------|
|-----------------|-------------------|-----------------|
|      Year       |    Millimeter     |      Inches     |
|-----------------|-------------------|-----------------|
|     Year 1      |       4.9         |      0.193      |
|-----------------|-------------------|-----------------|
|     Year 2      |       8.0         |      0.315      |
|-----------------|-------------------|-----------------|
|     Year 3      |       11.1        |      0.437      |
|-----------------|-------------------|-----------------|
|     Year 4      |       14.2        |      0.559      |
|-----------------|-------------------|-----------------|
|     Year 5      |       17.3        |      0.681      |
|-----------------|-------------------|-----------------|

|------------------ Ocean Rise Table -------------------|
|-----------------|-------------------|-----------------|
|      Year       |   Mean Temp(◦F)   |  Mean Temp(◦C)  |
|-----------------|-------------------|-----------------|
|     Year 1      |      92.130       |      33.406     |
|-----------------|-------------------|-----------------|
|     Year 2      |       92.26       |      33.478     |
|-----------------|-------------------|-----------------|
|     Year 3      |      92.390       |      33.55      |
|-----------------|-------------------|-----------------|
|     Year 4      |       92.52       |      33.622     |
|-----------------|-------------------|-----------------|
|     Year 5      |      92.650       |      33.694     |
|-----------------|-------------------|-----------------|


*/
