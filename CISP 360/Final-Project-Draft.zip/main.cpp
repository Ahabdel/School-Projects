// main.cpp
// Ahmad Abdelrahman
// 07/31/2024

#include <iostream>
#include <fstream>
#include <ctime>
#include <iomanip>
#include <cstdlib>
#include <limits>

using namespace std;

// Speciﬁcation C1 - Main Data Structure 
const int HOUSE_SIZE = 5;
const int MONSTER_COUNT = 4;
const int MAX_INVENTORY_SIZE = 10;
const char PLAYER = 'P';
const char SAFE_ROOM = 'S';
const char EMPTY = '.';
const char ZOMBIE = 'Z';
const char CREEPER = 'C';
const char SKELETON = 'K';
const char SPIDER = 'R';

const string MONSTERS[4] = { "Zombie", "Creeper", "Skeleton", "Spider" };
const string TREASURES[3] = { "Cake", "Bottle o' Enchanting", "Music Disc" };


// Room structure
struct HouseRoom {

    string room_name;
    string room_description;
    int room_id;
    bool occupied;
    char exits[4];
    bool visited;
    bool has_trap;
    string treasure;
    string brief_description;

};

// Speciﬁcation C2 - Three Functions 
void ProgramGreeting();
void LogFunctionCall(const string &function_name);
void InitializeHouse(char house[HOUSE_SIZE][HOUSE_SIZE], int player_pos[2], int safe_room_pos[2], int monsters[MONSTER_COUNT][2], HouseRoom rooms[HOUSE_SIZE][HOUSE_SIZE], char monster_types[MONSTER_COUNT]);
void DisplayHouse(char house[HOUSE_SIZE][HOUSE_SIZE]);
void MovePlayer(char direction, char house[HOUSE_SIZE][HOUSE_SIZE], int player_pos[2], int &player_health, int monsters[MONSTER_COUNT][2], HouseRoom rooms[HOUSE_SIZE][HOUSE_SIZE], char monster_types[MONSTER_COUNT], string inventory[MAX_INVENTORY_SIZE], int &inventory_size);
void LookAround(HouseRoom &room, int &player_health, string inventory[MAX_INVENTORY_SIZE], int &inventory_size);
void EncounterMonster(char house[HOUSE_SIZE][HOUSE_SIZE], int player_pos[2], int &player_health, int monsters[MONSTER_COUNT][2], char monster_types[MONSTER_COUNT]);
void KillMonster(char house[HOUSE_SIZE][HOUSE_SIZE], int player_pos[2], int monsters[MONSTER_COUNT][2], char monster_types[MONSTER_COUNT]);
void EncounterTrap(HouseRoom &room, int &player_health);
void DisplayInventory(const string inventory[MAX_INVENTORY_SIZE], int inventory_size);
void ShowAllResults();
void PlayGame();
void ExplainGame();
void ShowControls();
void GameMenu();
void LogGameResult(const string &result, int health_left);
void UseTreasure(string &treasure, int &player_health, string inventory[MAX_INVENTORY_SIZE], int &inventory_size, bool from_inventory = false);
void PickUpTreasure(HouseRoom &room, int &player_health, string inventory[MAX_INVENTORY_SIZE], int &inventory_size);
void UseItemFromInventory(int &player_health, string inventory[MAX_INVENTORY_SIZE], int &inventory_size);
void AskTrapQuestion(int &player_health);


int main() {
    
    ProgramGreeting();
    GameMenu();
    return 0;
    
}

// Function implementations
void ProgramGreeting() {
    
    cout << "Welcome.... Are you Ready to Explore? \n" << endl
         << "---------------------"
         << "\nAHMAD MINECRAFT 2D\n"
         << "---------------------\n"
         << "\n- A text-based adventure game where the player navigates a house to reach the safe room while avoiding or defeating zombies, creepers, skeletons, and spiders and traps.\n";
    
    LogFunctionCall("ProgramGreeting");
}

// Speciﬁcation C3 - Function Activity to Disk
void LogFunctionCall(const string &function_name) {
    
    ofstream log_file("log.txt", ios_base::app);
    
    if (log_file.is_open()) {
        
        time_t now = time(nullptr);
        log_file << put_time(localtime(&now), "%Y-%m-%d %H:%M:%S") << " - Function called: " << function_name << "\n";
        log_file.close(); 
    }
    
}

void InitializeHouse(char house[HOUSE_SIZE][HOUSE_SIZE], int player_pos[2], int safe_room_pos[2], int monsters[MONSTER_COUNT][2], HouseRoom rooms[HOUSE_SIZE][HOUSE_SIZE], char monster_types[MONSTER_COUNT]) {

    // Specification B1 - Abbreviated Room Description
    for (int i = 0; i < HOUSE_SIZE; ++i) {
        for (int j = 0; j < HOUSE_SIZE; ++j) {
            house[i][j] = EMPTY;
            rooms[i][j] = {"Room " + to_string(i) + "-" + to_string(j), 
                           "This is the description of Room " + to_string(i) + "-" + to_string(j) + ".", 
                           i * HOUSE_SIZE + j, 
                           false, 
                           {'n', 's', 'e', 'w'}, 
                           false, 
                           false, 
                           "",
                           "You are back in Room " + to_string(i) + "-" + to_string(j) + "."
                          };
        }
    }

    // Speciﬁcation B2 - Detailed Look
    // Room Descriptions and Names
    rooms[0][0].room_name = "\n*************\nEntrance Hall\n*************\n";
    rooms[0][0].room_description = "Room Description: \nYou stand in the grand entrance hall of a large mansion. Dusty chandeliers hang from the ceiling, and cobwebs cling to the corners of the room.\n";
    rooms[0][0].brief_description = "You are back in the grand entrance hall, with its dusty chandeliers and cobwebs in the corners.";

    rooms[0][1].room_name = "\n-----------\nDining Room\n-----------\n";
    rooms[0][1].room_description = "Room Description: \nA large dining table dominates the center of the room, surrounded by old wooden chairs. The table is set as if waiting for a meal that never came.\n";
    rooms[0][1].brief_description = "You are back in the dining room with a large table set as if waiting for a meal.";
    
    rooms[0][2].room_name = "\n-----------\nKitchen Room\n-----------\n";
    rooms[0][2].room_description = "Room Description: \nThe kitchen is filled with dusty, old appliances and a lingering smell of decay. Broken dishes and pots are scattered across the floor.\n";
    rooms[0][2].brief_description = "You are back in the kitchen filled with dusty, old appliances and a lingering smell of decay.";

    rooms[0][3].room_name = "\n-----------\nLibrary\n-----------\n";
    rooms[0][3].room_description = "Room Description: \nShelves filled with ancient books line the walls. The air is thick with the scent of aged paper and leather. A large, dusty armchair sits in one corner.\n";
    rooms[0][3].brief_description = "You are back in the library with shelves of ancient books and a large, dusty armchair.";

    rooms[0][4].room_name = "\n-----------\nHidden Room\n-----------\n";
    rooms[0][4].room_description = "Room Description: \nYou discovered a hidden room behind a bookcase. It's dark and full of cobwebs. Various trinkets and old furniture are haphazardly stored here.\n";
    rooms[0][4].brief_description = "You are back in the hidden room behind the bookcase, dark and full of cobwebs.";
    
    rooms[1][0].room_name = "\n-----------\nStudy\n-----------\n";
    rooms[1][0].room_description = "Room Description: \nAn old wooden desk sits in the center of the room, covered in papers and a broken lamp. Shelves of books and maps line the walls.\n";
    rooms[1][0].brief_description = "You are back in the study with an old wooden desk covered in papers and a broken lamp.";

    rooms[1][1].room_name = "\n-----------\nMaster Bedroom\n-----------\n";
    rooms[1][1].room_description = "Room Description: \nA grand bed with tattered curtains dominates the room. The wardrobe doors are open, revealing clothes from a bygone era. A large, cracked mirror hangs on one wall.\n";
    rooms[1][1].brief_description = "You are back in the master bedroom with a grand bed and a large, cracked mirror.";

    rooms[1][2].room_name = "\n-----------\nBathroom\n-----------\n";
    rooms[1][2].room_description = "Room Description: \nThe bathroom is eerily quiet. The bathtub is filled with stagnant water, and the mirror above the sink is cracked. Mold covers the tiles.\n";
    rooms[1][2].brief_description = "You are back in the eerily quiet bathroom with a stagnant bathtub and mold-covered tiles.";

    rooms[1][3].room_name = "\n-----------\nBasement\n-----------\n";
    rooms[1][3].room_description = "Room Description: \nThe basement is cold and damp. Rusty tools and broken furniture are scattered around. The smell of mildew is overwhelming.\n";
    rooms[1][3].brief_description = "You are back in the cold and damp basement filled with rusty tools and broken furniture.";

    rooms[1][4].room_name = "\n-----------\nAttic\n-----------\n";
    rooms[1][4].room_description = "Room Description: \nThe attic is cluttered with old furniture, trunks, and boxes filled with forgotten items. The wooden floor creaks with every step.\n";
    rooms[1][4].brief_description = "You are back in the cluttered attic with old furniture and creaky wooden floors.";


    rooms[2][0].room_name = "\n-----------\nGarden\n-----------\n";
    rooms[2][0].room_description = "Room Description: \nThe garden is overgrown with weeds and vines. Statues and benches are barely visible through the foliage. A faint path leads deeper into the garden.\n";
    rooms[2][0].brief_description = "You are back in the overgrown garden with statues and benches barely visible through the foliage.";

    rooms[2][1].room_name = "\n-----------\nGreenhouse\n-----------\n";
    rooms[2][1].room_description = "Room Description: \nThe greenhouse is filled with overgrown plants and broken glass. The air is thick with humidity, and the sound of dripping water echoes around you.\n";
    rooms[2][1].brief_description = "You are back in the greenhouse filled with overgrown plants and broken glass.";

    rooms[2][2].room_name = "\n-----------\nConservatory\n-----------\n";
    rooms[2][2].room_description = "Room Description: \nThe conservatory is filled with musical instruments covered in dust. An old piano sits in the corner, and sheet music is scattered across the floor.\n";
    rooms[2][2].brief_description = "You are back in the conservatory filled with dusty musical instruments and scattered sheet music.";

    rooms[2][3].room_name = "\n-----------\nTrophy Room\n-----------\n";
    rooms[2][3].room_description = "Room Description: \nThe walls are lined with hunting trophies and old weapons. A large fireplace dominates one wall, and a bearskin rug lies on the floor.\n";
    rooms[2][3].brief_description = "You are back in the trophy room lined with hunting trophies and old weapons.";

    rooms[2][4].room_name = "\n-----------\nNursery\n-----------\n";
    rooms[2][4].room_description = "Room Description: \nThe nursery is filled with old toys and a small, dusty crib. The wallpaper is faded and peeling, and the room feels strangely cold.\n";
    rooms[2][4].brief_description = "You are back in the nursery filled with old toys and a small, dusty crib.";

    rooms[3][0].room_name = "\n-----------\nGuest Room\n-----------\n";
    rooms[3][0].room_description = "Room Description: \nThe guest room is simple, with a small bed and a nightstand. The bed is neatly made, but everything is covered in a thick layer of dust.\n";
    rooms[3][0].brief_description = "You are back in the simple guest room with a small bed and a nightstand.";

    rooms[3][1].room_name = "\n-----------\nWine Cellar\n-----------\n";
    rooms[3][1].room_description = "Room Description: \nThe wine cellar is cool and damp. Racks of dusty wine bottles line the walls, and a large, wooden table sits in the center of the room.\n";
    rooms[3][1].brief_description = "You are back in the cool and damp wine cellar filled with racks of dusty wine bottles.";

    rooms[3][2].room_name = "\n-----------\nServant's Quarters\n-----------\n";
    rooms[3][2].room_description = "Room Description: \nThe servant's quarters are small and cramped. Bunk beds line the walls, and a small table is covered in old, yellowing newspapers.\n";
    rooms[3][2].brief_description = "You are back in the cramped servant's quarters with bunk beds and old newspapers.";

    rooms[3][3].room_name = "\n-----------\nArmory\n-----------\n";
    rooms[3][3].room_description = "Room Description: \nThe armory is filled with suits of armor, swords, and shields. The weapons are old but well-maintained, and the air smells of metal and oil.\n";
    rooms[3][3].brief_description = "You are back in the armory filled with suits of armor, swords, and shields.";

    rooms[3][4].room_name = "\n-----------\nPotion Room\n-----------\n";
    rooms[3][4].room_description = "Room Description: \nShelves filled with colorful bottles and jars line the walls. A large cauldron sits in the center, bubbling with a mysterious liquid. The room is filled with the scents of herbs and spices.\n";
    rooms[3][4].brief_description = "You are back in the potion room filled with colorful bottles and a bubbling cauldron.";

    rooms[4][0].room_name = "\n-----------\nArt Gallery\n-----------\n";
    rooms[4][0].room_description = "Room Description: \nThe art gallery is filled with paintings and sculptures. The paintings are covered in dust, and some frames are broken. The eerie silence adds to the room's mysterious aura.\n";
    rooms[4][0].brief_description = "You are back in the art gallery filled with dusty paintings and broken frames.";

    rooms[4][1].room_name = "\n-----------\nMusic Room\n-----------\n";
    rooms[4][1].room_description = "Room Description: \nThe music room contains various instruments, including a grand piano and several violins. Sheet music is strewn about, and the air carries a faint, melancholic melody.\n";
    rooms[4][1].brief_description = "You are back in the music room filled with various instruments and strewn sheet music.";

    rooms[4][2].room_name = "\n-----------\nSecret Laboratory\n-----------\n";
    rooms[4][2].room_description = "Room Description: \nThis hidden laboratory is filled with strange equipment and bubbling potions. The air is thick with the scent of chemicals, and the faint hum of machinery can be heard.\n";
    rooms[4][2].brief_description = "You are back in the hidden laboratory filled with strange equipment and bubbling potions.";

    rooms[4][3].room_name = "\n-----------\nChapel\n-----------\n";
    rooms[4][3].room_description = "Room Description: \nThe chapel is small and dimly lit, with wooden pews and a dusty altar. Stained glass windows cast colorful shadows on the floor, creating an ethereal atmosphere.\n";
    rooms[4][3].brief_description = "You are back in the small, dimly lit chapel with stained glass windows casting colorful shadows.";

    rooms[4][4].room_name = "\n************\nSafe Room\n************\n";
    rooms[4][4].room_description = "Room Description: \nThis is the safe room. You win! The room is clean and well-lit, a stark contrast to the rest of the mansion. Safety and relief wash over you.\n";
    rooms[4][4].brief_description = "You are back in the clean and well-lit safe room, a stark contrast to the rest of the mansion.";
    
    
    // Player's Starting Location
    player_pos[0] = 0;
    player_pos[1] = 0;
    house[player_pos[0]][player_pos[1]] = PLAYER;

    // Safe Room's Location AKA End Goal
    safe_room_pos[0] = HOUSE_SIZE - 1;
    safe_room_pos[1] = HOUSE_SIZE - 1;
    house[safe_room_pos[0]][safe_room_pos[1]] = SAFE_ROOM;

    // Randomly Place Monsters on MAP
    srand(time(0));
    char monster_symbols[MONSTER_COUNT] = {ZOMBIE, CREEPER, SKELETON, SPIDER};
    for (int i = 0; i < MONSTER_COUNT; ++i) {

        int x, y;
        do {

            x = rand() % HOUSE_SIZE;
            y = rand() % HOUSE_SIZE;
        } while (house[x][y] != EMPTY || (x == safe_room_pos[0] && y == safe_room_pos[1]));
        monsters[i][0] = x;
        monsters[i][1] = y;
        house[x][y] = monster_symbols[i];
        monster_types[i] = monster_symbols[i];
        rooms[x][y].occupied = true;
        
    }

        // Randomly Place Treasures and Healing Stuff on MAP
    for (int i = 0; i < 3; ++i) {

        int x, y;
        do {

            x = rand() % HOUSE_SIZE;
            y = rand() % HOUSE_SIZE;
            
        } while (house[x][y] != EMPTY || rooms[x][y].occupied || (x == safe_room_pos[0] && y == safe_room_pos[1]));
        rooms[x][y].treasure = TREASURES[i];
    }

    // Randomly Place traps on MAP
    for (int i = 0; i < 3; ++i) {

        int x, y;
        do {

            x = rand() % HOUSE_SIZE;
            y = rand() % HOUSE_SIZE;
        } while (house[x][y] != EMPTY || rooms[x][y].occupied || !rooms[x][y].treasure.empty() || (x == safe_room_pos[0] && y == safe_room_pos[1]));
        rooms[x][y].has_trap = true;
    }

    LogFunctionCall("InitializeHouse");
}

// Shows the player the Map
void DisplayHouse(char house[HOUSE_SIZE][HOUSE_SIZE]) {
    
    LogFunctionCall("DisplayHouse");
    
    for (int i = 0; i < HOUSE_SIZE; ++i) {
        
        for (int j = 0; j < HOUSE_SIZE; ++j) {
            
            cout << house[i][j] << " ";
            
        }
        
        cout << "\n";
    }
}

// Specification A1 - Add more command options.
// Player can now move within the map 'W' for up, 'S' for down, 'A' for left, 'D' for right
void MovePlayer(char direction, char house[HOUSE_SIZE][HOUSE_SIZE], int player_pos[2], int &player_health, int monsters[MONSTER_COUNT][2], HouseRoom rooms[HOUSE_SIZE][HOUSE_SIZE], char monster_types[MONSTER_COUNT], string inventory[MAX_INVENTORY_SIZE], int &inventory_size) {

    LogFunctionCall("MovePlayer");
    
    int new_x = player_pos[0];
    int new_y = player_pos[1];

    if (direction == 'n') {
        
        new_x--;
        
    } else if (direction == 'w') {
        
        new_y--;
        
    } else if (direction == 's') {
        
        new_x++;
        
    } else if (direction == 'e') {
        
        new_y++;
        
    } else {
        return;
    }

    if (new_x >= 0 && new_x < HOUSE_SIZE && new_y >= 0 && new_y < HOUSE_SIZE) {

        house[player_pos[0]][player_pos[1]] = EMPTY;
        player_pos[0] = new_x;
        player_pos[1] = new_y;
        house[player_pos[0]][player_pos[1]] = PLAYER;

        if (!rooms[player_pos[0]][player_pos[1]].visited) {

            cout << rooms[player_pos[0]][player_pos[1]].room_name << "\n";
            cout << rooms[player_pos[0]][player_pos[1]].room_description << "\n";

        } else {

            cout << rooms[player_pos[0]][player_pos[1]].room_name << "\n";
            cout << rooms[player_pos[0]][player_pos[1]].brief_description << "\n";

        }

        rooms[player_pos[0]][player_pos[1]].visited = true;
        EncounterMonster(house, player_pos, player_health, monsters, monster_types);
        EncounterTrap(rooms[player_pos[0]][player_pos[1]], player_health);

    } else {

        cout << "You can't move in that direction.\n";

    }
    
}


void LookAround(HouseRoom &room, int &player_health, string inventory[MAX_INVENTORY_SIZE], int &inventory_size) {
    
    LogFunctionCall("LookAround");
    cout << room.room_name << "\n";
    cout << room.room_description << "\n";
    
    if (!room.treasure.empty()) {
        
        cout << "You see a " << room.treasure << " here.\n";
        
    }
    
}

void EncounterMonster(char house[HOUSE_SIZE][HOUSE_SIZE], int player_pos[2], int &player_health, int monsters[MONSTER_COUNT][2], char monster_types[MONSTER_COUNT]) {
    
    LogFunctionCall("EncounterMonster");
    
    for (int i = 0; i < MONSTER_COUNT; ++i) {

          if (player_pos[0] == monsters[i][0] && player_pos[1] == monsters[i][1]) {

              if (monster_types[i] == 'Z') {
                  
                  cout << "A Zombie attacks you!\n";
                  player_health -= 20;
                  
              } else if (monster_types[i] == 'C') {
                  
                  cout << "A Creeper explodes near you!\n";
                  player_health -= 30;
                  
              } else if (monster_types[i] == 'K') {
                  
                  cout << "A Skeleton shoots an arrow at you!\n";
                  player_health -= 25;
                  
              } else if (monster_types[i] == 'R') {
                  
                  cout << "A Spider bites you!\n";
                  player_health -= 15;
                  
              }
            return;
        }
    }
}

// Specification A2 - Combat Feature
// Player can kill monsters when they are at the same location as that monster
void KillMonster(char house[HOUSE_SIZE][HOUSE_SIZE], int player_pos[2], int monsters[MONSTER_COUNT][2], char monster_types[MONSTER_COUNT]) {
    
    LogFunctionCall("KillMonster");
    
    for (int i = 0; i < MONSTER_COUNT; ++i) {

        if (player_pos[0] == monsters[i][0] && player_pos[1] == monsters[i][1]) {

            cout << "You killed a " << MONSTERS[monster_types[i] == 'Z' ? 0 : monster_types[i] == 'C' ? 1 : monster_types[i] == 'K' ? 2 : 3] << "!\n";
            house[monsters[i][0]][monsters[i][1]] = PLAYER;
            monsters[i][0] = -1;
            monsters[i][1] = -1;
            return;
        }
    }
    cout << "No monster here to kill.\n";
}

void EncounterTrap(HouseRoom &room, int &player_health) {
    
    LogFunctionCall("EncounterTrap");
    
    if (room.has_trap) {
        
        cout << "You triggered a trap! Answer the question to pass safely.\n";
        AskTrapQuestion(player_health);
        room.has_trap = false; // Trap is deactivated after being triggered
        
    }
}

// Specification A3 - Player can see their inventory
// In certain locations on the map, the player can collect stuff in their inventory, through this function they can see all that is in their inventory
void DisplayInventory(const string inventory[MAX_INVENTORY_SIZE], int inventory_size) {
    
    LogFunctionCall("DisplayInventory");
    
    cout << "Inventory:\n";
    for (int i = 0; i < inventory_size; ++i) {
        
        cout << "- " << inventory[i] << "\n";
        
    }
}

void ShowAllResults() {
    
    LogFunctionCall("ShowAllResults");
    
    ifstream log_file("results.txt");
    if (log_file.is_open()) {
        
        string line;
        while (getline(log_file, line)) {
            
            cout << line << "\n";
            
        }
        
        log_file.close();
        
    } else {
        
        cout << "No results found.\n";
        
    }
}

void LogGameResult(const string &result, int health_left) {

    ofstream results_file("results.txt", ios_base::app);
    
    if (results_file.is_open()) {
        
        time_t now = time(nullptr);
        results_file << put_time(localtime(&now), "%Y-%m-%d %H:%M:%S") << " - " << result << " with " << health_left << " health left.\n";
        results_file.close();
        
    }
}


void UseTreasure(string &treasure, int &player_health, string inventory[MAX_INVENTORY_SIZE], int &inventory_size, bool from_inventory) {
    
    if (treasure == "Cake" || treasure == "Bottle o' Enchanting") {
        
        char choice;
        cout << "Do you want to use the " << treasure << " now? (y/n): ";
        cin >> choice;
        
        if (choice == 'y' || choice == 'Y') {
            
            if (treasure == "Cake") {
                
                player_health += 10;
                cout << "You used the Cake and gained 10 health points. Your current health: " << player_health << "\n";
                
            } else if (treasure == "Bottle o' Enchanting") {
                
                player_health = 100;
                cout << "You used the Bottle o' Enchanting and your health is now full. Your current health: " << player_health << "\n";
                
            }
            
        } else {
            
            if (inventory_size < MAX_INVENTORY_SIZE) {
                
                inventory[inventory_size++] = treasure;
                cout << "You stored the " << treasure << " in your inventory.\n";
                
            } else {
                
                cout << "Your inventory is full. You cannot store the " << treasure << ".\n";
                
            }
        }
        
    } else if (treasure == "Music Disc") {
        
        if (inventory_size < MAX_INVENTORY_SIZE) {
            
            inventory[inventory_size++] = treasure;
            cout << "You stored the " << treasure << " in your inventory.\n";
            
        } else {
            
            cout << "Your inventory is full. You cannot store the " << treasure << ".\n";
            
        }
    }
    
    treasure = "";
}


void PickUpTreasure(HouseRoom &room, int &player_health, string inventory[MAX_INVENTORY_SIZE], int &inventory_size) {
    
    if (!room.treasure.empty()) {
        
        cout << "You found a " << room.treasure << "!\n";
        UseTreasure(room.treasure, player_health, inventory, inventory_size);
        
    } else {
        
        cout << "No treasure to pick up in this room.\n";
        
    }
}

void UseItemFromInventory(int &player_health, string inventory[MAX_INVENTORY_SIZE], int &inventory_size) {
    
    if (inventory_size == 0) {
        
        cout << "Your inventory is empty.\n";
        return;
        
    }

    cout << "Choose an item to use:\n";
    
    for (int i = 0; i < inventory_size; ++i) {
        
        cout << i + 1 << ". " << inventory[i] << "\n";
        
    }
    
    int choice;
    cout << "Enter the number of the item to use: ";
    cin >> choice;

    if (choice > 0 && choice <= inventory_size) {
        
        string item = inventory[choice - 1];
        UseTreasure(item, player_health, inventory, inventory_size, true);

        // Remove the used item from inventory
        for (int i = choice - 1; i < inventory_size - 1; ++i) {
            
            inventory[i] = inventory[i + 1];
            
        }
        
        --inventory_size;
        
    } else {
        
        cout << "Invalid choice. No item used.\n";
        
    }
}

void AskTrapQuestion(int &player_health) {
    
    string question = "What is the capital of France?";
    string options[4] = {"1. Berlin", "2. Madrid", "3. Paris", "4. Rome"};
    int correct_answer = 3;

    cout << question << "\n";
    
    for (int i = 0; i < 4; ++i) {
        
        cout << options[i] << "\n";
        
    }
    
    int answer;
    cout << "Enter the number of your answer: ";
    cin >> answer;

    if (answer == correct_answer) {
        
        cout << "Correct! You passed the trap safely.\n";
        
    } else {
        
        cout << "Incorrect! You lost 10 health points.\n";
        player_health -= 10;
        
    }
}

void ShowControls() {
    
    LogFunctionCall("ShowControls");
    
    cout << "\nGame Controls:\n--------------\n";
    cout << "N - Move up\n";
    cout << "W - Move left\n";
    cout << "S - Move down\n";
    cout << "E - Move right\n";
    cout << "l - Look around the room\n";
    cout << "p - Pick up treasure\n";
    cout << "k - Kill a monster\n";
    cout << "c - Show controls\n";
    cout << "i - Check inventory\n";
    cout << "u - Use an item from inventory\n";
    cout << "q - Quit the game\n";
    
}

void PlayGame() {

    
    char house[HOUSE_SIZE][HOUSE_SIZE];
    int player_pos[2];
    int safe_room_pos[2];
    int monsters[MONSTER_COUNT][2];
    char monster_types[MONSTER_COUNT];
    HouseRoom rooms[HOUSE_SIZE][HOUSE_SIZE];
    int player_health = 100;
    string inventory[MAX_INVENTORY_SIZE];
    int inventory_size = 0;
 

    InitializeHouse(house, player_pos, safe_room_pos, monsters, rooms, monster_types);

    cout << rooms[player_pos[0]][player_pos[1]].room_name << "\n";
    cout << rooms[player_pos[0]][player_pos[1]].room_description << "\n";
    rooms[player_pos[0]][player_pos[1]].visited = true;
    
    // THE GAME
    char command;
    
    do {
        
        cout << "\n--------------------"
             << "\nMap of Your Location\n"
             << "--------------------\n" << endl;
        DisplayHouse(house);
        cout << "\nYour Health: " << player_health << "\n";
        cout << "Enter command (c: to view controls, q: quit): ";
        cin >> command;
        command = tolower(command);

        // COMMANDS AND RESPONSE
        if (command == 'n' || command == 'w' || command == 's' || command == 'e') {
            
            MovePlayer(command, house, player_pos, player_health, monsters, rooms, monster_types, inventory, inventory_size);
            
        } else if (command == 'l') {
            
            LookAround(rooms[player_pos[0]][player_pos[1]], player_health, inventory, inventory_size);
            
        } else if (command == 'p') {
            
            PickUpTreasure(rooms[player_pos[0]][player_pos[1]], player_health, inventory, inventory_size);
            
        } else if (command == 'k') {
            
            KillMonster(house, player_pos, monsters, monster_types);
            
        } else if (command == 'c') {
            
            ShowControls();
            
        } else if (command == 'i') {
            
            DisplayInventory(inventory, inventory_size);
            
        } else if (command == 'u') {
            
            UseItemFromInventory(player_health, inventory, inventory_size);
            
        } else if (command == 'q') {
            
            cout << "Thanks for playing!\n";
            LogGameResult("Quit", player_health);
            return;
            
        } else {
            
            cout << "Invalid command. Please try again.\n";
            
        }


        // Check if player reached the safe room
        if (player_pos[0] == safe_room_pos[0] && player_pos[1] == safe_room_pos[1]) {
            
            cout << "Congratulations! You have reached the safe room. You win!\n";
            
            LogGameResult("Win", player_health);
            return;
            
        }

        // DID PLAYER SURVIVE?
        if (player_health <= 0) {
            
            cout << "You have died. Game over.\n";
            
            LogGameResult("Loss", player_health);
            return;
            
        }

    } while (true);
    
}


void ExplainGame() {
    
    LogFunctionCall("ExplainGame");

    // Explanation Text By Me
    cout << "\nGame Explanation:\n"
         << "-------------------\n";
    cout << "\nNarrator(Ahmad): 'Hi, my name is Ahmad and welcome to the New Minecraft 2D discovery game'\n";
    cout << "\nNarrator(Ahmad): 'Let's talk about how to play. Your goal is to navigate through the house to reach the safe room without losing all your health from the monsters and traps you may encounter a long the way.''\n";
    cout << "\nNarrator(Ahmad): Here are all the tools you need: (Controls) \n"
         << "'N' to move up\n"
         << "'S' to move down\n"
         << "'E' to move right\n"
         << "'W' to move left\n"
         << "'i' to check inventory\n"
         << "'k' to fight Monsters\n"
         << "'p' to pick up Treasures\n"
         << "'u' to use Inventory\n"
         << "'L' to look around\n";
    cout << "\nREMINDER: **You will encounter various monsters including Zombies, Creepers, Skeletons, and Spiders, each causing different damage.**\n";
    cout << "\nIMPORTANT: **Along your way there will also be treasures that you can collect, some of these treasures will give you some health back that you lost in your combat with monsters.**\n";
    cout << "\nNarrator(Ahmad): 'Alright, now that you know the rules, let's get to work. Try your best to avoid traps, monsters and dying and reach the safe room to win the game.''" << endl << "\nNarrator(Ahmad): '....Good luck!'\n";
    
}

void GameMenu() {

    // Game Main Menu (Combination of what we learned in the course)
    int choice;
    
    do {
        
        cout << "\nGame Menu:\n";
        cout << "1. Explain Game\n";
        cout << "2. Play\n";
        cout << "3. Show All Results\n";
        cout << "4. Quit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        // Specification B3 - Input Validation 
        while (cin.fail() || choice < 1 || choice > 4) {
            
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout << "Invalid choice. Please enter a number between 1 and 4: ";
            cin >> choice;
            
        }
        
        if (choice == 1) {
            ExplainGame();
        } else if (choice == 2) {
            PlayGame();
        } else if (choice == 3) {
            ShowAllResults();
        } else if (choice == 4) {
            cout << "Quitting the game. Goodbye!\n";
        } else {
            cout << "Invalid choice. Please try again.\n";
        }
        
    } while (choice != 4);
}






/*
Commented Sample Run:


Welcome.... Are you Ready to Explore? 
---------------------
AHMAD MINECRAFT 2D
---------------------

- A text-based adventure game where the player navigates a house to reach the safe room while avoiding or defeating zombies, creepers, skeletons, and spiders and traps.

Game Menu:
1. Explain Game
2. Play
3. Show All Results
4. Quit
Enter your choice: 2

*************
Entrance Hall
*************

Room Description: 
You stand in the grand entrance hall of a large mansion. Dusty chandeliers hang from the ceiling, and cobwebs cling to the corners of the room.


--------------------
Map of Your Location
--------------------

P . K R . 
. . Z . . 
. . . . . 
. C . . . 
. . . . S 

Your Health: 100
Enter command (c: to view controls, q: quit): c

Game Controls:
----------
n - Move up
w - Move left
s - Move down
e - Move right
l - Look around the room
p - Pick up treasure
k - Kill a monster
c - Show controls
i - Check inventory
u - Use an item from inventory
q - Quit the game

--------------------
Map of Your Location
--------------------

P . K R . 
. . Z . . 
. . . . . 
. C . . . 
. . . . S 

Your Health: 100
Enter command (c: to view controls, q: quit): e

-----------
Dining Room
-----------

Room Description: 
A large dining table dominates the center of the room, surrounded by old wooden chairs. The table is set as if waiting for a meal that never came.


--------------------
Map of Your Location
--------------------

. P K R . 
. . Z . . 
. . . . . 
. C . . . 
. . . . S 

Your Health: 100
Enter command (c: to view controls, q: quit): s

-----------
Master Bedroom
-----------

Room Description: 
A grand bed with tattered curtains dominates the room. The wardrobe doors are open, revealing clothes from a bygone era. A large, cracked mirror hangs on one wall.


--------------------
Map of Your Location
--------------------

. . K R . 
. P Z . . 
. . . . . 
. C . . . 
. . . . S 

Your Health: 100
Enter command (c: to view controls, q: quit): s

-----------
Greenhouse
-----------

Room Description: 
The greenhouse is filled with overgrown plants and broken glass. The air is thick with humidity, and the sound of dripping water echoes around you.


--------------------
Map of Your Location
--------------------

. . K R . 
. . Z . . 
. P . . . 
. C . . . 
. . . . S 

Your Health: 100
Enter command (c: to view controls, q: quit): e

-----------
Conservatory
-----------

Room Description: 
The conservatory is filled with musical instruments covered in dust. An old piano sits in the corner, and sheet music is scattered across the floor.


--------------------
Map of Your Location
--------------------

. . K R . 
. . Z . . 
. . P . . 
. C . . . 
. . . . S 

Your Health: 100
Enter command (c: to view controls, q: quit): e

-----------
Trophy Room
-----------

Room Description: 
The walls are lined with hunting trophies and old weapons. A large fireplace dominates one wall, and a bearskin rug lies on the floor.

You triggered a trap! Answer the question to pass safely.
What is the capital of France?
1. Berlin
2. Madrid
3. Paris
4. Rome
Enter the number of your answer: 3
Correct! You passed the trap safely.

--------------------
Map of Your Location
--------------------

. . K R . 
. . Z . . 
. . . P . 
. C . . . 
. . . . S 

Your Health: 100
Enter command (c: to view controls, q: quit): s

-----------
Armory
-----------

Room Description: 
The armory is filled with suits of armor, swords, and shields. The weapons are old but well-maintained, and the air smells of metal and oil.

You triggered a trap! Answer the question to pass safely.
What is the capital of France?
1. Berlin
2. Madrid
3. Paris
4. Rome
Enter the number of your answer: 3
Correct! You passed the trap safely.

--------------------
Map of Your Location
--------------------

. . K R . 
. . Z . . 
. . . . . 
. C . P . 
. . . . S 

Your Health: 100
Enter command (c: to view controls, q: quit): s

-----------
Chapel
-----------

Room Description: 
The chapel is small and dimly lit, with wooden pews and a dusty altar. Stained glass windows cast colorful shadows on the floor, creating an ethereal atmosphere.

You triggered a trap! Answer the question to pass safely.
What is the capital of France?
1. Berlin
2. Madrid
3. Paris
4. Rome
Enter the number of your answer: 3
Correct! You passed the trap safely.

--------------------
Map of Your Location
--------------------

. . K R . 
. . Z . . 
. . . . . 
. C . . . 
. . . P S 

Your Health: 100
Enter command (c: to view controls, q: quit): e

************
Safe Room
************

Room Description: 
This is the safe room. You win! The room is clean and well-lit, a stark contrast to the rest of the mansion. Safety and relief wash over you.

You have reached the safe room. You win!

Game Menu:
1. Explain Game
2. Play
3. Show All Results
4. Quit
Enter your choice: 3
2024-08-01 00:36:23 - Quit with 30 health left.
2024-08-01 00:46:54 - Quit with 100 health left.
2024-08-01 03:09:13 - Win with 100 health left.

Game Menu:
1. Explain Game
2. Play
3. Show All Results
4. Quit
Enter your choice: 4
Quitting the game. Goodbye!

*/