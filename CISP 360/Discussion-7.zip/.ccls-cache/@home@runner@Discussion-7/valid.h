#ifndef VALID_H
#define VALID_H

#include <iostream>
#include <fstream>
#include <string>

namespace validation {

using namespace std;

// Validates for integer input
int getInteger(const string& prompt = "Enter integer: ") {
    int num = 0;
    cout << prompt;
    cin >> num;
    while (!cin || cin.peek() != '\n') {
        cin.clear();
        cin.ignore(100, '\n');
        cout << "Invalid integer. Try again.\n";
        cout << prompt;
        cin >> num;
    }
    return num;
}

// Validates for float input
float getFloat(const string& prompt = "Enter float: ") {
    float num = 0;
    cout << prompt;
    cin >> num;
    while (!cin) {
        cin.clear();
        cin.ignore(100, '\n');
        cout << "Invalid float. Try again.\n";
        cout << prompt;
        cin >> num;
    }
    return num;
}

// Opens a file for input
bool openFile(ifstream& infile, const string& fileName) {
    infile.open(fileName);
    if (!infile) {
        cout << "Error opening file: " << fileName << endl;
        return false;
    }
    return true;
}

// Opens a file for output
bool openFile(ofstream& outfile, const string& fileName) {
    outfile.open(fileName);
    if (!outfile) {
        cout << "Error opening file: " << fileName << endl;
        return false;
    }
    return true;
}

} // namespace validation

#endif // VALID_H