/******************************************************************************
# Author:           Ahmad Abdelrahman, Erik laun, Lorcan Delong
# Assignment:       Discussion 5
# Date:             05/02/2024
# Description:      
# Sources:          https://learn.zybooks.com/ # replit.com # C ++ Style Guide
# Work Divide:      Ahmad: Planning doc
#                   Erik: debugging, formatting, comments 
#                   Lorcan: output style / style guide / arrays
# Struggled most:   Erik: debugging 
#                   Ahmad:
#                   Lorcan: understanding files
#******************************************************************************/

#include <iostream>
#include <fstream>
#include <string>
#include <iomanip> // For setprecision
#include "valid.h" // For file opening and input validation functions

namespace STEM {

using namespace std;
using namespace validation;

// function prototypes
void ratioCalc(ifstream& inFile);

const int MAX = 100;

// Main function
int main() {
    ifstream inFile;
    string fileName = "stem.txt";

    if (!openFile(inFile, fileName)) {
        cout << "File did not open. Program terminating!!!\n";
        return 0;
    }

    ratioCalc(inFile);
    inFile.close();

    return 0;
}


// Function to calculate the ratios and write results to the output file
// pre: passed infile and ifstream
// post: calculations made and output to file
void ratioCalc(ifstream& inFile) {
    ofstream outFile("stemout.txt");
    if (!outFile) {
        cout << "Failed to open output file. Program terminating!!!\n";
        return;
    }
    string line;
    getline(inFile, line); // Skip the header line

    string major[MAX];
    int men[MAX];
    int women[MAX];
    int salary[MAX];
    int i = 0;
    int highest_salary = 0;
    string highest_salary_major;
    int lowest_salary = 1e9; // Large initial value for finding the minimum
    string lowest_salary_major;

    while (inFile >> major[i] >> men[i] >> women[i] >> salary[i]) {
        double total = men[i] + women[i];
        double percentMen = (men[i] / total) * 100;
        double percentWomen = (women[i] / total) * 100;

        outFile << fixed << setprecision(2);
        outFile << "\nMajor: " << major[i] << "\nPercent men: " << percentMen 
                << "%\nPercent women: " << percentWomen << "%" << endl;

        if (salary[i] > highest_salary) {
            highest_salary = salary[i];
            highest_salary_major = major[i];
        }
        if (salary[i] < lowest_salary) {
            lowest_salary = salary[i];
            lowest_salary_major = major[i];
        }
        i++;
    }

    // Optionally output highest and lowest salary majors
    outFile << "\nHighest Salary Major: " << highest_salary_major << " with $"
            << highest_salary << endl;
    outFile << "Lowest Salary Major: " << lowest_salary_major << " with $"
            << lowest_salary << endl;

    outFile.close();
}

} // namespace STEM


// External main function reference
int main() {
    return STEM::main();
}
