/******************************************************************************
# Author:           Ahmad Abdelrahman, Erik laun
# Assignment:       Discussion 4
# Date:             04/12/2024
# Description:      "My Credit Union" is a basic console-based banking
#                   application developed in C++. It allows users to view
#                   their balance, deposit funds, and withdraw money, all with
#                   strict input validation for error-free operations. The
#                   simple menu-driven interface ensures ease of use and
#                   straightforward financial management.
# Sources:          https://learn.zybooks.com/ # replit.com # C ++ Style Guide
# Work Divide:      Ahmad: Creating menu validation
#                   Erik: getDeposit() function, debuggings, and comments
# Struggled most:   Erik: Correcting errors in the code, debugging
#                   Ahmad: Figuring out how to include valid.h
#******************************************************************************/
// Welcome to My Credit Union

// 1. View balance
// 2. Make deposit
// 3. Withdraw funds
// 4. Quit

// Enter choice: 1
// Account balance: $ 0.00

// Enter choice: 2
// Enter deposit amount $ 150.60

// Enter choice: 1
// Account balance: $ 150.60

// Enter choice: 3
// Enter withdraw amount $ 10.23

// Enter choice: 1
// Account balance: $ 140.37

// Enter choice: 4

// Thank you for using My Credit Union!

#include "valid.h"
#include <iomanip>
#include <iostream>
using namespace std;

// function prototypes
void printMenu();
void viewBalance(float balance);
int getChoice();
float getDeposit();
float getWithdraw(float balance);

const int QUIT = 4;

int main() {
  int choice = 0;
  float balance = 0.0;
  float deposit = 0.0;
  float withdraw = 0.0;

  cout << "Welcome to My Credit Union!" << endl;

  while (choice != QUIT) {
    printMenu();
    choice = getChoice();

    switch (choice) {
    case 1:
      viewBalance(balance);
      break;
    case 2:
      balance += getDeposit();
      break;
    case 3:
      balance -= getWithdraw(balance);
      break;
    case 4:
      // Quitting the menu
      break;
    }
  }

  cout << "\nThank you for using My Credit Union" << endl;

  return 0;
}

void printMenu() {
  cout << "\n1. View balance" << endl;
  cout << "2. Make deposit" << endl;
  cout << "3. Withdraw funds" << endl;
  cout << "4. Quit" << endl;
}

void viewBalance(float balance) {
  cout << fixed << setprecision(2);
  cout << "Account balance $" << balance << endl;
}

int getChoice() {
  int choice = getInteger("Enter choice (1-4): ");
  while (choice < 1 || choice > 4) {
    cout << "Invalid choice. Please enter a number between 1 and 4: ";
    choice = getInteger();
  }
  return choice;
}

float getDeposit() {
  float deposit = getFloat("Enter deposit amount $ ");
  while (deposit < 0) {
    cout << "Invalid amount. Please enter a non-negative number: ";
    deposit = getFloat();
  }
  return deposit;
}

float getWithdraw(float balance) {
  float withdraw = getFloat("Enter withdraw amount $ ");
  while (withdraw < 0 || withdraw > balance) {
    if (withdraw < 0) {
      cout << "Invalid amount. Please enter a non-negative number: ";
    } else {
      cout << "Insufficient funds. Please enter a smaller amount: ";
    }
    withdraw = getFloat();
  }
  return withdraw;
}