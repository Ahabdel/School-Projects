/******************************************************************************
# Author:           Ahmad Abdelrahman, Erik laun
# Assignment:       Discussion 5
# Date:             04/12/2024
# Description:      The "Travel Distance and Speed Calculator" is designed to 
#                   compute the average speed of a journey by taking user 
#                   inputs for the start and end locations, the distance
#                   traveled, and the time taken for the journey. This application 
#                   is useful for travelers or anyone interested in measuring 
#                   travel efficiency over specific routes.
# Sources:          https://learn.zybooks.com/ # replit.com # C ++ Style Guide
# Work Divide:      Ahmad: Added logic for duplicates and for ordering.
#                   Erik: Debugging, comments, and code organization. 
# Struggled most:   Erik: debugging, making dupliclate work. 
#                   Ahmad: Adding logic for duplicates
#******************************************************************************/

#include <algorithm> // For sort()
#include <cstdlib>   // For rand() and srand()
#include <ctime>     // For time()
#include <iostream>
#include <vector>

using namespace std;

int main() {
    // Seed the random number generator
    srand(time(0));

    vector<int> lottery(5);
    vector<int> picks(5);

    // Generate random lottery numbers without duplicates
    for (int i = 0; i < 5; i++) {
        int newNumber;
        bool isDuplicate = true; // Initialize flag to true

        while (isDuplicate) {
            isDuplicate = false; // Reset flag
            newNumber = rand() % 10;

            // Check if the new number is a duplicate
            for (int j = 0; j < i; j++) {
                if (lottery[j] == newNumber) {
                    isDuplicate = true;
                    // Exit the loop if a duplicate is found
                }
            }
        }

        lottery[i] = newNumber;
    }

  
    // Check for duplicates in lottery numbers
    sort(lottery.begin(), lottery.end());
    for (int i = 0; i < 4; i++) {
        if (lottery[i] == lottery[i + 1]) {
            return 0;
        }
    }

    cout << "Enter 5 unique numbers (0-9):" << endl;

  
    // Get user picks and validates it
    int i = 0;
    bool validInput = false;
    while (i < 5) {
        int input;

        cin >> input;

        if (input < 0 || input > 9) {
            cout << "Invalid number, please enter a number between 0 and 9: ";
        } else {
          
            // Check for duplicates in picks, exits loop if duplicate found
            bool isDuplicate = false; 
            for (int j = 0; j < i; j++) {
                if (picks[j] == input) {
                    isDuplicate = true;
                }
            }
          
            if (isDuplicate) {
                cout << "No duplicates allowed, enter a unique number: ";
            } else {
                picks[i] = input;
                validInput = true;
                i++; 
            }
        }
    }

  
    // Sort the arrays for order-independent comparison
    sort(picks.begin(), picks.end());

  
    // Check for match
    bool isWinner = (lottery == picks);
    int matchCount = 0;

    for (int i = 0; i < 5; i++) {
        if (lottery[i] == picks[i]) {
            matchCount++;
        }
    }

  
    // Display the lottery and user picks
    cout << "Lottery numbers: ";
    for (int num : lottery) {
        cout << num << " ";
    }
    cout << endl;

    cout << "Your picks: ";
    for (int num : picks) {
        cout << num << " ";
    }
    cout << endl;

    // Output results
    if (isWinner) {
        cout << "Congratulations! You are a winner!" << endl;
    } else {
        cout << "Sorry, you did not win. You matched " << matchCount 
          << " numbers." << endl;
    }

    return 0;
}