// main.cpp
// Ahmad Abdelrahman
// 07/5/2024

#include <iostream>
#include <iomanip>
#include <ctime>
#include <cctype>
#include <algorithm>
#include <string>
#include <stack>
using namespace std;



string ObjectName = "Enter";
bool ObjectNameCheck = false;
bool isValid;
float ObjectTemp;
float convertedTemp;
int objCode;
int MenuConversion;
float LowCat = 85.8;
float HighCat = 102.2;
float LowCot = 53.8;
float HighCot = 80.2;
float LowCap = 71.8;
float HighCap = 88.2;
int Prompt(const string& message);
float PromptFloat(const string& message, bool isFloat);
string PromptString(const string& message, bool isString);

// Specification A3 - Stack
stack<string> conversionResults;




// Speciﬁcation C3 – Three Functions 
void welcome();
void CatCalc();
void CotCalc();
void CapCalc();
void CalcConvert();
void CheckObject();
string toLower(const string& str);
bool ValFlo();
int MenuOptions();
void MenuConvert();
void ProgramEnd();
void FHT2Celsius();
void FHT2Kelvine();
void FHT2Rankine();
void Tables();
void DisplayStack();



int main() {

  welcome();
  ObjectName = PromptString("Please type which object you want to calculate (cat, cot, cap): ", true);
  ObjectName = toLower(ObjectName);
  CheckObject();
  MenuConvert();
  Tables();
  ObjectTemp = PromptFloat("Please enter the object's temperature in Fahrenheit: ", true);
  ValFlo();
  if (ObjectName == "cat") {
    CatCalc();
  } else if (ObjectName == "cot") {
    CotCalc();
  } else if (ObjectName == "cap") {
    CapCalc();
  }
  DisplayStack();
  ProgramEnd();
  
  return 0;
}


void welcome() {
  // Speciﬁcation B1 – Display Function Activity
  time_t now = time(0); 

  char* dt = ctime(&now);
  cout << "Program Start" << endl << "Function main() started" << endl;
  cout << "Function ProgramGreeting() started" << endl << "This is my program greeting…\n" << endl;
  cout << "Hello, Welcome to Ahmad's Cat, Cot, Cap Temperature Calculator!\n" << "Author: Ahmad Abdelrahman" << endl << dt << endl;

}

void MenuConvert() {
  if (ObjectName == "cat" || ObjectName == "cot" || ObjectName == "cap") {
      MenuConversion = MenuOptions();
  }
}

// Speciﬁcation C2 – Select Temp Scale Menu 
int MenuOptions() {
  int MenuConversion;
  cout << "Select Temperature Scale for Conversion: \n"
    "1. Celsius\n"
    "2. Kelvine\n"
    "3. Rankine\n"
    // Specification A2 - All Temp Conversion
    "4. Convert All\n"
    "Type Menu Option:";
    cin >> MenuConversion;
    while (MenuConversion < 1 || MenuConversion > 4) {
    cout << endl << "Please Enter a Valid Menu:"; 
    cin >> MenuConversion;
  }
  
  return MenuConversion;
}



void CatCalc() {
  if (MenuConversion == 1) {
    FHT2Celsius();
  } else if (MenuConversion == 2) {
    FHT2Kelvine();
  } else if (MenuConversion == 3) {
    FHT2Rankine();
  } else if (MenuConversion == 4) {
    FHT2Celsius();
    FHT2Kelvine();
    FHT2Rankine();
  }
}
void CotCalc() {
  if (MenuConversion == 1) {
    FHT2Celsius();
  } else if (MenuConversion == 2) {
    FHT2Kelvine();
  } else if (MenuConversion == 3) {
    FHT2Rankine();
  } else if (MenuConversion == 4) {
    FHT2Celsius();
    FHT2Kelvine();
    FHT2Rankine();
  }
}
void CapCalc() {
  if (MenuConversion == 1) {
    FHT2Celsius();
  } else if (MenuConversion == 2) {
    FHT2Kelvine();
  } else if (MenuConversion == 3) {
    FHT2Rankine();
  } else if (MenuConversion == 4) {
    FHT2Celsius();
    FHT2Kelvine();
    FHT2Rankine();
  }
}


// Speciﬁcation B2 – Valid Temps Only 

bool ValFlo() {
    bool isValid = false;

    while (!isValid) {
        if (ObjectName == "cat") {
            if (ObjectTemp < LowCat) {
                cout << "Too Low! Try Again: ";
                cin >> ObjectTemp;
            } else if (ObjectTemp > HighCat) {
                cout << "Too High! Try Again: ";
                cin >> ObjectTemp;
            } else {
                cout << "Value Stored.\n";
                isValid = true;
            }
        } else if (ObjectName == "cot") {
            if (ObjectTemp < LowCot) {
                cout << "Too Low! Try Again: ";
                cin >> ObjectTemp;
            } else if (ObjectTemp > HighCot) {
                cout << "Too High! Try Again: ";
                cin >> ObjectTemp;
            } else {
                cout << "Value Stored.\n";
                isValid = true;
            }
        } else if (ObjectName == "cap") {
            if (ObjectTemp < LowCap) {
                cout << "Too Low! Try Again: ";
                cin >> ObjectTemp;
            } else if (ObjectTemp > HighCap) {
                cout << "Too High! Try Again: ";
                cin >> ObjectTemp;
            } else {
                cout << "Value Stored.\n";
                isValid = true;
            }
        }
    }

    return isValid;
}


// Speciﬁcation C1 – Only Valid Words 
void CheckObject() {
  while (ObjectNameCheck == false) {
  if (ObjectName == "cat") {
    
    ObjectNameCheck = true;
  } else if (ObjectName == "cot") {
    
    ObjectNameCheck = true;
  } else if (ObjectName == "cap") {
    
    ObjectNameCheck = true;
  } else {
    
    ObjectName = PromptString("Enter a valid input (cat, cot, cap): ", true);
    ObjectName = toLower(ObjectName);
  }
  }
}


void FHT2Celsius() {
  convertedTemp = (ObjectTemp - 32) * 5 / 9;
  string result = "Temperature in Celsius: " + to_string(convertedTemp) + "°C";
  cout << result << endl;
  conversionResults.push(result);
}
void FHT2Kelvine() {
  convertedTemp = (ObjectTemp - 32) * 5 / 9 + 273.15;
  string result = "Temperature in Kelvin: " + to_string(convertedTemp) + "K";
  cout << result << endl;
  conversionResults.push(result);
}
void FHT2Rankine() {
  convertedTemp = ObjectTemp + 459.67;
  string result = "Temperature in Rankine: " + to_string(convertedTemp) + "°R";
  cout << result << endl;
  conversionResults.push(result);
}
string toLower(const string& str) {
    string lowerStr = str;
    transform(lowerStr.begin(), lowerStr.end(), lowerStr.begin(), ::tolower);
    return lowerStr;
}

// Specification A1 - All Temps Table
void DisplayStack() {
    cout << "\nConversion Results:" << endl;
    while (!conversionResults.empty()) {
        cout << conversionResults.top() << endl;
        conversionResults.pop();
    }
}
void Tables() {
    
  if (ObjectName == "cat") {
     
    cout << "-----------------------------------------------\n"
         << "|       Low Temp       |       High Temp      |\n"
         << "-----------------------------------------------\n"
         << "|         86.0°F       |         102.0°F      |\n"
         << "-----------------------------------------------\n"
         << "|         30.0°C       |         38.89°C      |\n"
         << "-----------------------------------------------\n"
         << "|        303.15K       |         312.0°K      |\n"
         << "-----------------------------------------------\n"
         << "|        545.6°R       |         561.6°R      |\n"
         << "-----------------------------------------------\n";
  } else if (ObjectName == "cat") {
      
    cout << "-----------------------------------------------\n"
       << "|       Low Temp       |       High Temp      |\n"
       << "-----------------------------------------------\n"
       << "|        54.0°F        |         80.0°F       |\n"
       << "-----------------------------------------------\n"
       << "|        12.22°C       |         26.67°C      |\n"
       << "-----------------------------------------------\n"
       << "|        285.37K       |         299.81K      |\n"
       << "-----------------------------------------------\n"
       << "|        513.67°R      |         561.6°R      |\n"
       << "-----------------------------------------------\n";
    
  } else if (ObjectName == "cap") {
      
    cout << "-----------------------------------------------\n"
       << "|       Low Temp       |       High Temp      |\n"
       << "-----------------------------------------------\n"
       << "|        72.0°F        |         88.0°F       |\n"
       << "-----------------------------------------------\n"
       << "|        22.22°C       |         31.11°C      |\n"
       << "-----------------------------------------------\n"
       << "|        295.37K       |        304.26K       |\n"
       << "-----------------------------------------------\n"
       << "|        531.6°R       |        539.67°R      |\n"
       << "-----------------------------------------------\n";
    
  }
}

int Prompt(const string& message) {
  int value;
  cout << message;
  while (!(cin >> value)) {
      cout << "Invalid input. Please enter a valid number: ";
      cin.clear();
      cin.ignore(123, '\n');
  }
  return value;
}

float PromptFloat(const string& message, bool isFloat) {
  float value;
  cout << message;
  while (!(cin >> value)) {
      cout << "Invalid input. Please enter a valid number: ";
      cin.clear();
      cin.ignore(123, '\n');
  }
  return value;
}

string PromptString(const string& message, bool isString) {
  string value;
  cout << message;
  cin >> value;
  return value;
}

void ProgramEnd() {
  cout << "Thank you for using Ahmad's Cat, Cot, Cap Temperature Calculator!";
}



// Speciﬁcation B3 - Overloaded Prompt Functions 



// Commented Sample Run:
/*

Hello, Welcome to Ahmad's Cat, Cot, Cap Temperature Calculator!
Author: Ahmad Abdelrahman
System Date: 06/13/204

Please Type Which Object You Want To Calculate:

**User Input**: Cat

Select Temperature Scale for Conversion:
1. Celsius
2. Kelvine
3. Rankine
4. Convert All

Select Menu #:
**User Input**: 1

What is the Temperature of the Cat in Fahrenheit?
**User Input**: 74
Invalid Temperature Range! Too Low!
Choose a Temperature within this range for Cat:
-----------------------------------------------
|       Low Temp       |       High Temp      |
-----------------------------------------------
|         86.0°F       |         102.0°F      |
-----------------------------------------------
|         30.0°C       |         38.89°C      |
-----------------------------------------------
|        303.15K       |         312.0°K      |
-----------------------------------------------
|        545.6°R       |         561.6°R      |
-----------------------------------------------

*****Validates if Input is within Range*****
**User Input**: 88.0°F
Stored Value: 88.0°F


Cot
-----------------------------------------------
|       Low Temp       |       High Temp      |
-----------------------------------------------
|        54.0°F        |         80.0°F       |
-----------------------------------------------
|        12.22°C       |         26.67°C      |
-----------------------------------------------
|        285.37K       |         299.81K      |
-----------------------------------------------
|        513.67°R      |         561.6°R      |
-----------------------------------------------

Cap
-----------------------------------------------
|       Low Temp       |       High Temp      |
-----------------------------------------------
|        72.0°F        |         88.0°F       |
-----------------------------------------------
|        22.22°C       |         31.11°C      |
-----------------------------------------------
|        295.37K       |        304.26K       |
-----------------------------------------------
|        531.6°R       |        539.67°R      |
-----------------------------------------------


RANKINE FORMULA: F + 459.67
KELVIN FORMULA: (F − 32) × 5 ⁄ 9 + 273.15
CELSIUS FORMULA: (°F - 32) × 5/9

*/









